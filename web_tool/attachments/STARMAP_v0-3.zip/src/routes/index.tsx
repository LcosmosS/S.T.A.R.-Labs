import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { catalogStats, getCatalog } from "@/lib/star/catalog";
import { OrbitCloud } from "@/components/viz/orbit-cloud";
import { Formula as Eq, Metric, Sym } from "@/components/viz/formula";
import { FILAMENTS, hEff, H0_PLANCK, H0_SHOES, PROJECTED } from "@/lib/star/physics";
import { useLab } from "@/lib/star/store";

export const Route = createFileRoute("/")({ component: Home });

const CHAPTERS = [
  {
    to: "/charter",
    kicker: "Charter v1",
    title: "What the program asks",
    body: "Not “elliptic curves determine the universe.” Correspondence is a test: arithmetic maps vs independent structure, with locked nulls and a claim registry.",
  },
  {
    to: "/dynamics",
    kicker: "Paper §14–26",
    title: "Unified matter dynamics",
    body: "The same A(φ, ℳ, 𝒥_Q) generates point-particle motion, perfect-fluid Euler, the stress tensor, and field exchange. Dust agrees with the worldline equation.",
  },
  {
    to: "/experiment",
    kicker: "RTCH-E1 · H₁–H₃",
    title: "Falsifiable topology",
    body: "Persistent H0, kNN Betti-1, geodesics, N1 column-permutation nulls — and rank vs density tertiles on Φ(E). A null result is a result.",
  },
  {
    to: "/hubble",
    kicker: "S.T.A.R.",
    title: "Scale-dependent Hubble",
    body: "Local sampling of ⟨Ω_E⟩_z plus entropy curvature lifts H_eff at low z without touching last scatter.",
  },
  {
    to: "/cohomology",
    kicker: "ECC / RTCH",
    title: "Charge vs scalar",
    body: "Q_RTCH[Σ₂] = ∫ Φ*ω is global. 𝒥_Q = ¼ F_Q² is the local invariant that may enter A. They must not be conflated.",
  },
  {
    to: "/theory",
    kicker: "Status",
    title: "Established vs conjectural",
    body: "Pullbacks and conformal matter coupling are differential geometry. ACSC arithmetic-as-thermodynamics remains a conjecture until independently validated.",
  },
] as const;

function Home() {
  const beta = useLab((s) => s.beta);
  const gamma = useLab((s) => s.gamma);
  const set = useLab((s) => s.set);
  const selected = useLab((s) => s.selectedLabel);
  const stats = catalogStats();
  const Hnow = hEff(0, getCatalog(), beta, gamma);
  const curve = PROJECTED.find((c) => c.label === selected) ?? PROJECTED[0];

  return (
    <div className="space-y-12">
      <section className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
        <div>
          <Badge tone="steel">Observatory</Badge>
          <h1 className="mt-4 font-display text-4xl leading-[1.05] tracking-tight text-fg sm:text-5xl lg:text-6xl">
            Correspondence first. Physics later.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted">
            STARMAP is the working laboratory for the S.T.A.R. Program and Relativistic Thermodynamic Cohomology. It
            does not assume that elliptic curves determine the universe. It tests whether a fixed arithmetic map
            produces structure that was not used to construct it — then, only then, asks whether RTCH can couple that
            structure to matter.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-6 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <Metric label="H_eff(0)" value={Hnow.toFixed(2)} unit="km/s/Mpc" hint={`SH0ES ${H0_SHOES.toFixed(2)}`} />
          <Metric label="Planck H0" value={H0_PLANCK.toFixed(1)} unit="km/s/Mpc" hint="CMB anchor" />
          <Metric label="Curves" value={String(stats.n)} hint={`${stats.famous} named · ${stats.ranks[1]} rank 1`} />
          <Metric label="⟨Ω_E⟩" value={stats.meanOmega.toFixed(3)} hint="catalog mean period" />
        </div>
      </section>

      <section className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
        <div className="flex items-center justify-between px-5 py-3">
          <div className="font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">Φ(E) · arithmetic point cloud</div>
          <div className="font-mono text-[10px] text-muted">Drag to orbit · click a curve</div>
        </div>
        <OrbitCloud
          points={PROJECTED}
          links={FILAMENTS}
          selected={selected}
          onSelect={(label) => set({ selectedLabel: label })}
          className="h-[min(62vh,540px)] w-full"
        />
        {curve ? (
          <div className="grid grid-cols-2 gap-4 border-t border-border px-5 py-4 sm:grid-cols-4">
            <Metric label="Label" value={curve.label} hint={curve.provenance} />
            <Metric label="Rank" value={String(curve.rank)} hint={`N = ${curve.conductor}`} />
            <Metric label="Regulator" value={curve.regulator.toFixed(4)} />
            <Metric label="Ω_E" value={curve.omega.toFixed(4)} hint="real period" />
          </div>
        ) : null}
      </section>

      <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {CHAPTERS.map((c) => (
          <Link
            key={c.to}
            to={c.to}
            className="group rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-steel">{c.kicker}</span>
              <ArrowUpRight className="size-4 text-subtle transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
            <h2 className="mt-3 font-display text-2xl tracking-tight">{c.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{c.body}</p>
          </Link>
        ))}
      </section>

      <section className="grid gap-8 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-2xl tracking-tight">Null hypothesis</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Appendix B of the variational paper isolates a single extra parameter. The extended model is supported only
            insofar as β_Q improves prediction while surviving independent nulls.
          </p>
          <div className="mt-5">
            <Eq boxed>
              H<sub className="font-sans text-sm not-italic">0</sub> : β<sub>Q</sub> = 0
            </Eq>
          </div>
        </div>
        <div>
          <h2 className="font-display text-2xl tracking-tight">Structural chain</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            A closed target two-form pulls back to a spacetime field strength. Its local scalar may enter the conformal
            factor. Matter then moves in Ã = A² g — particles and fluids alike.
          </p>
          <div className="mt-5">
            <Eq boxed>
              <Sym>F</Sym>
              <sub className="font-sans text-sm not-italic">Q</sub> = Φ<sup>*</sup>ω →{" "}
              <Sym>A</Sym>(φ, ℳ, 𝒥<sub>Q</sub>)
            </Eq>
          </div>
        </div>
      </section>
    </div>
  );
}
