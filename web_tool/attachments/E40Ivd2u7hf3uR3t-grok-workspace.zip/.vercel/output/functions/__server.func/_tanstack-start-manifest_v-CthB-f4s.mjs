//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CthB-f4s.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/action",
			"/catalog",
			"/cohomology",
			"/dynamics",
			"/experiment",
			"/hubble",
			"/projection",
			"/theory"
		],
		preloads: [
			"/assets/index-jAH-KvYp.js",
			"/assets/utils-D-TzktqB.js",
			"/assets/catalog-PUL_pLsL.js",
			"/assets/dist-DNDylhIt.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-jAH-KvYp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-buW_9Z82.js",
			"/assets/formula-DVQhAIlS.js",
			"/assets/orbit-cloud-ox0SK72T.js"
		]
	},
	"/action": {
		filePath: "/workspace/src/routes/action.tsx",
		children: void 0,
		preloads: [
			"/assets/action-iE8ogMpr.js",
			"/assets/slider-D1Bicuv9.js",
			"/assets/formula-DVQhAIlS.js",
			"/assets/switch-DtPqyfr0.js",
			"/assets/field-canvas-BPoocsLH.js"
		]
	},
	"/catalog": {
		filePath: "/workspace/src/routes/catalog.tsx",
		children: void 0,
		preloads: ["/assets/catalog-WM1BzSLk.js", "/assets/formula-DVQhAIlS.js"]
	},
	"/cohomology": {
		filePath: "/workspace/src/routes/cohomology.tsx",
		children: void 0,
		preloads: [
			"/assets/cohomology-BmceUMto.js",
			"/assets/slider-D1Bicuv9.js",
			"/assets/formula-DVQhAIlS.js",
			"/assets/switch-DtPqyfr0.js",
			"/assets/field-canvas-BPoocsLH.js"
		]
	},
	"/dynamics": {
		filePath: "/workspace/src/routes/dynamics.tsx",
		children: void 0,
		preloads: [
			"/assets/dynamics-DtZoQ2Yu.js",
			"/assets/slider-D1Bicuv9.js",
			"/assets/formula-DVQhAIlS.js",
			"/assets/switch-DtPqyfr0.js"
		]
	},
	"/experiment": {
		filePath: "/workspace/src/routes/experiment.tsx",
		children: void 0,
		preloads: ["/assets/experiment-fcZafufg.js", "/assets/formula-DVQhAIlS.js"]
	},
	"/hubble": {
		filePath: "/workspace/src/routes/hubble.tsx",
		children: void 0,
		preloads: [
			"/assets/hubble-LdHk2Dda.js",
			"/assets/slider-D1Bicuv9.js",
			"/assets/formula-DVQhAIlS.js"
		]
	},
	"/projection": {
		filePath: "/workspace/src/routes/projection.tsx",
		children: void 0,
		preloads: [
			"/assets/projection-CWbrFkXY.js",
			"/assets/formula-DVQhAIlS.js",
			"/assets/orbit-cloud-ox0SK72T.js"
		]
	},
	"/theory": {
		filePath: "/workspace/src/routes/theory.tsx",
		children: void 0,
		preloads: ["/assets/theory-Cm1RGuCm.js", "/assets/formula-DVQhAIlS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
