import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as useLab } from "./router-Cu8J75Dn.mjs";
import { n as Formula, r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
import { t as Slider } from "./slider-CCeJdzcU.mjs";
import { t as Switch } from "./switch-C144xYK6.mjs";
import { t as FieldCanvas } from "./field-canvas-DJmSkfIv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cohomology-KJKOjQpo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TorusMap({ params, className }) {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const paramsRef = (0, import_react.useRef)(params);
	paramsRef.current = params;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		let raf = 0;
		let t = 0;
		let running = true;
		const resize = () => {
			const r = wrap.getBoundingClientRect();
			canvas.width = Math.max(1, Math.floor(r.width * dpr));
			canvas.height = Math.max(1, Math.floor(r.height * dpr));
			canvas.style.width = `${r.width}px`;
			canvas.style.height = `${r.height}px`;
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(wrap);
		const draw = () => {
			if (!running) return;
			t += .016;
			const p = paramsRef.current;
			const w = canvas.width;
			const h = canvas.height;
			ctx.fillStyle = "#111318";
			ctx.fillRect(0, 0, w, h);
			const pad = 28 * dpr;
			const bw = w - pad * 2;
			const bh = h - pad * 2;
			ctx.strokeStyle = "rgba(255,255,255,0.1)";
			ctx.strokeRect(pad, pad, bw, bh);
			ctx.font = `${10 * dpr}px "IBM Plex Mono"`;
			ctx.fillStyle = "#8b919c";
			ctx.fillText("θ ~ θ+2π", pad, pad - 8 * dpr);
			ctx.fillText("φ", pad - 18 * dpr, pad + 12 * dpr);
			const n = 18;
			ctx.strokeStyle = "rgba(138,160,181,0.55)";
			ctx.lineWidth = Math.max(1, 1.1 * dpr);
			for (let i = 0; i <= n; i++) {
				ctx.beginPath();
				for (let j = 0; j <= 40; j++) {
					const u = i / n;
					const v = j / 40;
					const jit = p.freezeY ? 0 : .02 * Math.sin(t + 8 * u);
					const x = pad + u * p.windingU % 1 * bw + jit * bw;
					const y = pad + (v * p.windingV + .04 * Math.sin(2 * Math.PI * u + t * .4)) % 1 * bh;
					if (j === 0) ctx.moveTo(x, y);
					else ctx.lineTo(x, y);
				}
				ctx.stroke();
			}
			ctx.strokeStyle = "rgba(215,222,232,0.45)";
			for (let j = 0; j <= n; j++) {
				ctx.beginPath();
				for (let i = 0; i <= 40; i++) {
					const u = i / 40;
					const v = j / n;
					const x = pad + (u * p.windingU + .03 * Math.cos(2 * Math.PI * v - t * .3)) % 1 * bw;
					const y = pad + v * p.windingV % 1 * bh;
					if (i === 0) ctx.moveTo(x, y);
					else ctx.lineTo(x, y);
				}
				ctx.stroke();
			}
			ctx.fillStyle = "#d7dee8";
			ctx.font = `${12 * dpr}px "IBM Plex Mono"`;
			ctx.fillText(`deg (n,m) = (${p.windingU}, ${p.windingV})`, pad, h - 10 * dpr);
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
			ro.disconnect();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block size-full"
		})
	});
}
function CohomologyPage() {
	const lab = useLab();
	const [sample, setSample] = (0, import_react.useState)({
		q: 0,
		iqMean: 0,
		iqMax: 0,
		hNorm: 0,
		phiRms: 0,
		sourceJ: 0,
		aMean: 1
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "steel",
						children: "Entropy cohomology"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Global charge, local scalar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "A closed two-form ω on thermodynamic state space pulls back to F_Q = Φ*ω. Because d_𝒯 ω = 0, d F_Q = 0. The integral on a two-cycle is topological. The pointwise invariant 𝒥_Q = ¼ F_Q² is not. Mixing them is the error the paper exists to prevent."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
					boxed: true,
					children: [
						"Q",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", {
							className: "font-sans text-sm not-italic",
							children: "RTCH"
						}),
						"[Σ₂] = ∫",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Σ₂" }),
						" Φ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sup", { children: "*" }),
						"ω"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
					boxed: true,
					children: [
						"𝒥",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Q" }),
						" = ¼ F",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Q μν" }),
						" F",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Q" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sup", { children: "μν" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Q / 4π²",
						value: sample.q.toFixed(3),
						hint: "global / topological"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "⟨𝒥_Q⟩",
						value: sample.iqMean.toFixed(3),
						hint: "local scalar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "max 𝒥_Q",
						value: sample.iqMax.toFixed(3)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "‖H‖",
						value: sample.hNorm.toFixed(3),
						hint: "λ_Q F_Q source"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Pullback density on Σ₂"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {
						params: lab,
						onSample: setSample,
						className: "h-64 w-full sm:h-80"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Target T² · winding (n, m)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TorusMap, {
						params: lab,
						className: "h-64 w-full sm:h-80"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl tracking-tight",
							children: "Winding"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between font-mono text-[11px] text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "n" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: lab.windingU
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 4,
							step: 1,
							value: [lab.windingU],
							onValueChange: (v) => lab.set({ windingU: v[0] ?? 1 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between font-mono text-[11px] text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "m" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: lab.windingV
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 4,
							step: 1,
							value: [lab.windingV],
							onValueChange: (v) => lab.set({ windingV: v[0] ?? 1 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Freeze Y"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: lab.freezeY,
								onCheckedChange: (v) => lab.set({ freezeY: v })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Topological λ_Q"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: lab.topologyOn,
								onCheckedChange: (v) => lab.set({ topologyOn: v })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "ok",
							children: "Established"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "Pullback of a closed form is closed. If [ω] ≠ 0 in H²_dR(𝒯), the integral on a homologous two-cycle is invariant. d² = 0 forbids ω = d(dℳ) as a nontrivial class."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "warn",
							children: "Conjectural"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "That thermodynamic state space carries such a class, that 𝒥_Q is the physically relevant local invariant, and that A should depend on it, are model assumptions — not theorems."
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { CohomologyPage as component };
