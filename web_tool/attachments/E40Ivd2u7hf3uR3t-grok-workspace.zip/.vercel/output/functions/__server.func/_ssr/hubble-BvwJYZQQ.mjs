import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as getCatalog, a as H0_PLANCK, f as hEff, g as meanOmega, o as H0_SHOES, p as hLcdm, r as useLab, x as KAPPA_UCF, y as CLUSTERS } from "./router-Cu8J75Dn.mjs";
import { n as Formula, r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
import { t as Slider } from "./slider-CCeJdzcU.mjs";
import { a as CartesianGrid, i as Line, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hubble-BvwJYZQQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function inferredH0(zz, curves, beta, gamma) {
	const E = hLcdm(zz, 1);
	return hEff(zz, curves, beta, gamma) / E;
}
function HubblePage() {
	const z = useLab((s) => s.z);
	const beta = useLab((s) => s.beta);
	const gamma = useLab((s) => s.gamma);
	const set = useLab((s) => s.set);
	const curves = getCatalog();
	const zPlot = Math.min(z, 2.4);
	const series = (0, import_react.useMemo)(() => {
		const rows = [];
		for (let i = 0; i <= 48; i++) {
			const zz = i / 48 * 2.4;
			rows.push({
				z: Number(zz.toFixed(3)),
				star: Number(inferredH0(zz, curves, beta, gamma).toFixed(3)),
				planck: H0_PLANCK,
				shoes: H0_SHOES
			});
		}
		return rows;
	}, [
		beta,
		gamma,
		curves
	]);
	const H = inferredH0(zPlot, curves, beta, gamma);
	const om = meanOmega(curves, zPlot);
	const highZ = inferredH0(1100, curves, beta, gamma);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "warn",
						children: "Conjectural expansion"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Scale-dependent Hubble"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "S.T.A.R. treats the local expansion rate as a weighted real-period average plus entropy-curvature and metric-trace terms that decay toward last scatter. This is a phenomenological layer on ACSC, not a derivation from the RTCH action."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
				boxed: true,
				children: [
					"H",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", {
						className: "font-sans text-sm not-italic",
						children: "eff"
					}),
					"(z) = H",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", {
						className: "font-sans text-sm not-italic",
						children: "ΛCDM"
					}),
					"(z; H₀ ⟨Ω⟩_z) + β κ(z) + γ Tr(δg)"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "H0_eff(z)",
						value: H.toFixed(2),
						unit: "km/s/Mpc",
						hint: `z = ${zPlot.toFixed(2)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "SH0ES",
						value: H0_SHOES.toFixed(2),
						unit: "km/s/Mpc",
						hint: "local ladder"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Planck",
						value: H0_PLANCK.toFixed(1),
						unit: "km/s/Mpc",
						hint: "CMB"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "H_eff(z*)",
						value: highZ.toFixed(2),
						hint: "last scatter"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
					children: "Inferred H0 versus redshift"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-64 w-full sm:h-80",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: series,
							margin: {
								top: 8,
								right: 12,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { stroke: "rgba(255,255,255,0.06)" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "z",
									tick: {
										fill: "#8b919c",
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									domain: [64, 78],
									tick: {
										fill: "#8b919c",
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									contentStyle: {
										background: "#181c24",
										border: "1px solid #232831",
										borderRadius: 8
									},
									labelStyle: { color: "#8b919c" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "star",
									stroke: "#d7dee8",
									strokeWidth: 2,
									dot: false,
									name: "STARMAP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "shoes",
									stroke: "#c4a574",
									strokeWidth: 1,
									dot: false,
									name: "SH0ES"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "planck",
									stroke: "#8aa0b5",
									strokeWidth: 1,
									dot: false,
									name: "Planck"
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl tracking-tight",
							children: "Controls"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between font-mono text-[11px] text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "redshift z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: zPlot.toFixed(2)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 2.4,
							step: .01,
							value: [z],
							onValueChange: (v) => set({ z: v[0] ?? 0 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between font-mono text-[11px] text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "entropy curvature β" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: beta.toFixed(2)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 1.2,
							step: .01,
							value: [beta],
							onValueChange: (v) => set({ beta: v[0] ?? 0 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between font-mono text-[11px] text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "metric trace γ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								children: gamma.toFixed(2)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 1,
							step: .01,
							value: [gamma],
							onValueChange: (v) => set({ gamma: v[0] ?? 0 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "⟨Ω_E⟩_z",
							value: om.toFixed(4),
							hint: `κ_UCF = ${KAPPA_UCF}`
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl tracking-tight",
						children: "Cluster probe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Illustrative nearby overdensities used as a local sampling check, not a survey catalog."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]",
						children: CLUSTERS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-fg",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono text-[10px] text-subtle",
								children: [
									c.rMly,
									" Mly · rank ",
									c.rank
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-sm tabular-nums text-fg",
								children: c.hFactor.toFixed(4)
							})]
						}, c.name))
					})
				] })]
			})
		]
	});
}
//#endregion
export { HubblePage as component };
