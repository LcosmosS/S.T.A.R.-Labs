import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { C as getCatalog, S as catalogStats, a as H0_PLANCK, f as hEff, i as FILAMENTS, o as H0_SHOES, r as useLab, s as PROJECTED } from "./router-Cu8J75Dn.mjs";
import { i as Sym, n as Formula, r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
import { t as OrbitCloud } from "./orbit-cloud-CutwTzrs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-U4NqOG9I.js
var import_jsx_runtime = require_jsx_runtime();
var CHAPTERS = [
	{
		to: "/dynamics",
		kicker: "Paper §14–26",
		title: "Unified matter dynamics",
		body: "The same A(φ, ℳ, 𝒥_Q) generates point-particle motion, perfect-fluid Euler, the stress tensor, and field exchange. Dust agrees with the worldline equation."
	},
	{
		to: "/experiment",
		kicker: "RTCH-E1",
		title: "Falsifiable topology",
		body: "Persistent H0, kNN Betti-1, geodesics, and N1 column-permutation nulls on the arithmetic point cloud. A null result is a result."
	},
	{
		to: "/hubble",
		kicker: "S.T.A.R.",
		title: "Scale-dependent Hubble",
		body: "Local sampling of ⟨Ω_E⟩_z plus entropy curvature lifts H_eff at low z without touching last scatter."
	},
	{
		to: "/cohomology",
		kicker: "ECC / RTCH",
		title: "Charge vs scalar",
		body: "Q_RTCH[Σ₂] = ∫ Φ*ω is global. 𝒥_Q = ¼ F_Q² is the local invariant that may enter A. They must not be conflated."
	},
	{
		to: "/action",
		kicker: "Master action",
		title: "Variational system",
		body: "S = S_EH + S_φ + S_Y + S_B + S_top + S_m + S_GHY. Nested nulls (λ_Q, β_Q) isolate local from topological coupling."
	},
	{
		to: "/theory",
		kicker: "Status",
		title: "Established vs conjectural",
		body: "Pullbacks and conformal matter coupling are differential geometry. ACSC arithmetic-as-thermodynamics remains a conjecture until independently validated."
	}
];
function Home() {
	const beta = useLab((s) => s.beta);
	const gamma = useLab((s) => s.gamma);
	const set = useLab((s) => s.set);
	const selected = useLab((s) => s.selectedLabel);
	const stats = catalogStats();
	const Hnow = hEff(0, getCatalog(), beta, gamma);
	const curve = PROJECTED.find((c) => c.label === selected) ?? PROJECTED[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "steel",
						children: "Observatory"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-4xl leading-[1.05] tracking-tight text-fg sm:text-5xl lg:text-6xl",
						children: "Particle and fluid, from one coupling."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-base leading-relaxed text-muted",
						children: "STARMAP is the working laboratory for Relativistic Thermodynamic Cohomology and the S.T.A.R. Program. Matter sees Ã = A²(φ, ℳ, 𝒥_Q) g. Worldlines and continua are two regimes of the same action — not two analogies."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-6 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "H_eff(0)",
							value: Hnow.toFixed(2),
							unit: "km/s/Mpc",
							hint: `SH0ES ${H0_SHOES.toFixed(2)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Planck H0",
							value: H0_PLANCK.toFixed(1),
							unit: "km/s/Mpc",
							hint: "CMB anchor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Curves",
							value: String(stats.n),
							hint: `${stats.famous} named · ${stats.ranks[1]} rank 1`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "⟨Ω_E⟩",
							value: stats.meanOmega.toFixed(3),
							hint: "catalog mean period"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-5 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
							children: "Φ(E) · arithmetic point cloud"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-[10px] text-muted",
							children: "Drag to orbit · click a curve"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitCloud, {
						points: PROJECTED,
						links: FILAMENTS,
						selected,
						onSelect: (label) => set({ selectedLabel: label }),
						className: "h-[min(62vh,540px)] w-full"
					}),
					curve ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-4 border-t border-border px-5 py-4 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Label",
								value: curve.label,
								hint: curve.provenance
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Rank",
								value: String(curve.rank),
								hint: `N = ${curve.conductor}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Regulator",
								value: curve.regulator.toFixed(4)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Ω_E",
								value: curve.omega.toFixed(4),
								hint: "real period"
							})
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3",
				children: CHAPTERS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: c.to,
					className: "group rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] uppercase tracking-[0.16em] text-steel",
								children: c.kicker
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 text-subtle transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-2xl tracking-tight",
							children: c.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: c.body
						})
					]
				}, c.to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Null hypothesis"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Appendix B of the variational paper isolates a single extra parameter. The extended model is supported only insofar as β_Q improves prediction while surviving independent nulls."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
							boxed: true,
							children: [
								"H",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", {
									className: "font-sans text-sm not-italic",
									children: "0"
								}),
								" : β",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Q" }),
								" = 0"
							]
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Structural chain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "A closed target two-form pulls back to a spacetime field strength. Its local scalar may enter the conformal factor. Matter then moves in Ã = A² g — particles and fluids alike."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
							boxed: true,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sym, { children: "F" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", {
									className: "font-sans text-sm not-italic",
									children: "Q"
								}),
								" = Φ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sup", { children: "*" }),
								"ω →",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sym, { children: "A" }),
								"(φ, ℳ, 𝒥",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Q" }),
								")"
							]
						})
					})
				] })]
			})
		]
	});
}
//#endregion
export { Home as component };
