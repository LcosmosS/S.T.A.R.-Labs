import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as alphaQ, d as gradLnA, h as matterTrace, n as LIMIT_META, r as useLab, u as evaluateState, v as Button } from "./router-Cu8J75Dn.mjs";
import { n as Formula, r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
import { t as Slider } from "./slider-CCeJdzcU.mjs";
import { t as Switch } from "./switch-C144xYK6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dynamics-BV5pK42Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DynamicsCanvas({ params, running = true, onSample, className }) {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const paramsRef = (0, import_react.useRef)(params);
	paramsRef.current = params;
	const runningRef = (0, import_react.useRef)(running);
	runningRef.current = running;
	const onSampleRef = (0, import_react.useRef)(onSample);
	onSampleRef.current = onSample;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		let raf = 0;
		let t = 0;
		let alive = true;
		const particles = Array.from({ length: 36 }, (_, i) => ({
			x: .12 + i % 6 * .15,
			y: .14 + Math.floor(i / 6) * .14,
			vx: 0,
			vy: 0
		}));
		const GW = 28;
		const GH = 18;
		const off = document.createElement("canvas");
		off.width = GW;
		off.height = GH;
		const octx = off.getContext("2d");
		const img = ctx.createImageData(GW, GH);
		const resize = () => {
			const r = wrap.getBoundingClientRect();
			canvas.width = Math.max(1, Math.floor(r.width * dpr));
			canvas.height = Math.max(1, Math.floor(r.height * dpr));
			canvas.style.width = `${r.width}px`;
			canvas.style.height = `${r.height}px`;
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(wrap);
		const draw = () => {
			if (!alive) return;
			const p = paramsRef.current;
			const dt = .018;
			if (runningRef.current) t += dt;
			const w = canvas.width;
			const h = canvas.height;
			ctx.fillStyle = "#0c0e12";
			ctx.fillRect(0, 0, w, h);
			let k = 0;
			let aSum = 0;
			let residual = 0;
			let nRes = 0;
			let fPhi = 0;
			let fM = 0;
			let fQ = 0;
			const rho = 1;
			const press = Math.max(0, p.pressure);
			const Tm = matterTrace(rho, press);
			const denom = rho + press;
			for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) {
				const x = i / 27;
				const y = j / 17;
				const st = evaluateState(x, y, t, p);
				const g = gradLnA(x, y, t, p);
				press * (1 + .28 * Math.sin(2 * Math.PI * x) * Math.sin(2 * Math.PI * y));
				const dpx = press * .28 * 2 * Math.PI * Math.cos(2 * Math.PI * x) * Math.sin(2 * Math.PI * y);
				const dpy = press * .28 * 2 * Math.PI * Math.sin(2 * Math.PI * x) * Math.cos(2 * Math.PI * y);
				const axP = -g.dx;
				const ayP = -g.dy;
				const axF = -dpx / denom + Tm / denom * g.dx;
				const ayF = -dpy / denom + Tm / denom * g.dy;
				residual += Math.hypot(axP - axF, ayP - ayF);
				nRes += 1;
				aSum += st.A;
				fPhi += Math.abs(p.alphaPhi);
				fM += Math.abs(p.alphaA);
				fQ += Math.abs(st.JQ);
				const lum = Math.min(1, (st.A - .7) / 1.4);
				img.data[k++] = Math.floor(14 + 40 * lum);
				img.data[k++] = Math.floor(18 + 55 * lum);
				img.data[k++] = Math.floor(24 + 90 * lum);
				img.data[k++] = 255;
			}
			if (octx) {
				octx.putImageData(img, 0, 0);
				ctx.imageSmoothingEnabled = true;
				ctx.drawImage(off, 0, 0, w, h);
			}
			ctx.strokeStyle = "rgba(138,160,181,0.45)";
			ctx.lineWidth = Math.max(1, .8 * dpr);
			const gx = 10;
			const gy = 7;
			for (let j = 0; j < gy; j++) for (let i = 0; i < gx; i++) {
				const x = (i + .5) / gx;
				const y = (j + .5) / gy;
				const g = gradLnA(x, y, t, p);
				const px = press * .28 * 2 * Math.PI * Math.cos(2 * Math.PI * x) * Math.sin(2 * Math.PI * y);
				const py = press * .28 * 2 * Math.PI * Math.sin(2 * Math.PI * x) * Math.cos(2 * Math.PI * y);
				const ax = -px / denom + Tm / denom * g.dx;
				const ay = -py / denom + Tm / denom * g.dy;
				const cx = x * w;
				const cy = y * h;
				const s = 18 * dpr;
				ctx.beginPath();
				ctx.moveTo(cx, cy);
				ctx.lineTo(cx + ax * s, cy + ay * s);
				ctx.stroke();
			}
			if (runningRef.current) for (const part of particles) {
				const g = gradLnA(part.x, part.y, t, p);
				part.vx += -g.dx * dt * 1.8;
				part.vy += -g.dy * dt * 1.8;
				part.vx *= .975;
				part.vy *= .975;
				part.x += part.vx * dt;
				part.y += part.vy * dt;
				if (part.x < .02 || part.x > .98) part.vx *= -1;
				if (part.y < .02 || part.y > .98) part.vy *= -1;
				part.x = Math.min(.98, Math.max(.02, part.x));
				part.y = Math.min(.98, Math.max(.02, part.y));
			}
			for (const part of particles) {
				ctx.beginPath();
				ctx.arc(part.x * w, part.y * h, 2.4 * dpr, 0, Math.PI * 2);
				ctx.fillStyle = "#d7dee8";
				ctx.fill();
			}
			if (Math.floor(t * 4) !== Math.floor((t - dt) * 4)) onSampleRef.current?.({
				aMean: aSum / 504,
				residual: residual / Math.max(1, nRes),
				forcePhi: fPhi / 504,
				forceM: fM / 504,
				forceQ: fQ / 504,
				agree: residual / Math.max(1, nRes) < .08 + press * 2
			});
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => {
			alive = false;
			cancelAnimationFrame(raf);
			ro.disconnect();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block size-full"
		})
	});
}
var LIMITS = [
	"minimal",
	"gr",
	"local-only",
	"topo-only",
	"no-conformal",
	"frozen-y"
];
function DynamicsPage() {
	const lab = useLab();
	const [running, setRunning] = (0, import_react.useState)(true);
	const [sample, setSample] = (0, import_react.useState)({
		aMean: 1,
		residual: 0,
		forcePhi: 0,
		forceM: 0,
		forceQ: 0,
		agree: true
	});
	const aQ = alphaQ(lab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "steel",
						children: "Unified matter"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Particle and fluid from one A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "The variational paper's central claim is not a new force law pasted onto GR. Point particles and perfect fluids are two descriptions of S_m[Ψ_m, A²g]. Dots follow −∇ ln A. Arrows are the Euler field. At vanishing pressure they must agree."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
				boxed: true,
				children: [
					"S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "p" }),
					" = −m ∫ A(φ, ℳ, 𝒥",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Q" }),
					") ds"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "⟨A⟩",
						value: sample.aMean.toFixed(3),
						hint: lab.conformalOn ? "conformal on" : "A = 1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Dust residual",
						value: sample.residual.toFixed(3),
						hint: lab.pressure === 0 ? sample.agree ? "agrees with worldline" : "mismatch" : "p > 0 expected"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "α_Q",
						value: aQ.toFixed(3),
						hint: "β_Q / Λ_Q⁴"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "p / ρ",
						value: lab.pressure.toFixed(2),
						hint: "dust at 0"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Worldlines · Euler field · Ã = A² g"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => setRunning((v) => !v),
						children: running ? "Pause" : "Run"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DynamicsCanvas, {
					params: lab,
					running,
					onSample: setSample,
					className: "h-[min(56vh,460px)] w-full"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-[1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl tracking-tight",
							children: "Couplings"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "β_Q",
							value: lab.betaQ,
							min: 0,
							max: 1.2,
							step: .01,
							onChange: (v) => lab.set({ betaQ: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "Λ_Q",
							value: lab.lambdaScale,
							min: .4,
							max: 2,
							step: .02,
							onChange: (v) => lab.set({ lambdaScale: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "α_φ",
							value: lab.alphaPhi,
							min: 0,
							max: .8,
							step: .01,
							onChange: (v) => lab.set({ alphaPhi: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "α_A",
							value: lab.alphaA,
							min: 0,
							max: .8,
							step: .01,
							onChange: (v) => lab.set({ alphaA: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "pressure p",
							value: lab.pressure,
							min: 0,
							max: .45,
							step: .01,
							onChange: (v) => lab.set({ pressure: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Conformal A"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: lab.conformalOn,
								onCheckedChange: (v) => lab.set({ conformalOn: v })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Freeze Y (F_Q → 0)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: lab.freezeY,
								onCheckedChange: (v) => lab.set({ freezeY: v })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl tracking-tight",
						children: "Nested nulls (λ_Q, β_Q)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: LIMITS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => lab.applyLimit(id),
							className: "rounded-lg bg-elevated px-3 py-3 text-left shadow-[var(--shadow-border)] transition-shadow hover:shadow-[var(--shadow-border-hover)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-[10px] uppercase tracking-[0.14em] text-steel",
									children: LIMIT_META[id].pair
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-sm text-fg",
									children: LIMIT_META[id].label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted",
									children: LIMIT_META[id].note
								})
							]
						}, id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Particle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-lg tracking-tight",
							children: "u^μ ∇_μ u^ν = −c² h^νμ ∇_μ ln A"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "Automatically orthogonal to four-velocity: u_μ f^μ = 0, so u·u = −c² is preserved. The cohomological piece is −c² α_Q h^νμ ∇_μ 𝒥_Q."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Perfect fluid" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-lg tracking-tight",
							children: "a^ν = −h^νμ ∇_μ p / (ρ+p) + T_m / (ρ+p) h^νμ ∇_μ ln A"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "T_m = −ρ + 3p. Dust (p = 0) collapses to the worldline equation. That identity is the paper's consistency test — not an extra postulate."
						})
					]
				})]
			})
		]
	});
}
function Knob({ label, value, min, max, step, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex items-center justify-between font-mono text-[11px] text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums text-fg",
			children: value.toFixed(2)
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
		min,
		max,
		step,
		value: [value],
		onValueChange: (v) => onChange(v[0] ?? value)
	})] });
}
//#endregion
export { DynamicsPage as component };
