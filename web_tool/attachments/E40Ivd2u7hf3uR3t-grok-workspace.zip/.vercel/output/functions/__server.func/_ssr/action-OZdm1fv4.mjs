import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as alphaQ, n as LIMIT_META, r as useLab } from "./router-Cu8J75Dn.mjs";
import { n as Formula, r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
import { t as Slider } from "./slider-CCeJdzcU.mjs";
import { t as Switch } from "./switch-C144xYK6.mjs";
import { t as FieldCanvas } from "./field-canvas-DJmSkfIv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/action-OZdm1fv4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TERMS = [
	{
		id: "EH",
		title: "Einstein–Hilbert",
		body: "S_EH = (1/16πG) ∫ R √−g. Standard GR curvature, plus GHY on ∂M.",
		status: "established"
	},
	{
		id: "φ",
		title: "Scalar",
		body: "S_φ = −∫ [½ (∇φ)² + V(φ)] √−g. Sourced by α_φ T_m whenever A depends on φ.",
		status: "established"
	},
	{
		id: "Y",
		title: "Thermodynamic sigma model",
		body: "S_Y = −∫ [½ G_AB ∂Y^A ∂Y^B + U(Y)] √−g. Target Christoffel Γ^A_BC enter the EL equation.",
		status: "established"
	},
	{
		id: "B",
		title: "Two-form kinetic",
		body: "S_B = −½ ∫ H ∧ *H with H = dB. Gauge B → B + dΛ leaves H invariant.",
		status: "established"
	},
	{
		id: "top",
		title: "Topological coupling",
		body: "S_top = λ_Q ∫ B ∧ F_Q. Metric-independent: no direct T_μν, yet it sources B and Y.",
		status: "conjectural"
	},
	{
		id: "m",
		title: "Matter",
		body: "S_m[Ψ_m, Ã = A²(φ, ℳ, 𝒥_Q) g]. Conserved w.r.t. the physical metric, not the Einstein frame.",
		status: "conjectural"
	}
];
var EQUATIONS = [
	{
		title: "Einstein",
		tex: "G_μν = 8πG (Tᵐ + Tᵠ + Tʸ + Tᴮ + T^{Q,m})_{μν}"
	},
	{
		title: "Scalar",
		tex: "□φ − V'(φ) + α_φ T_m = 0"
	},
	{
		title: "Two-form",
		tex: "d * H + λ_Q F_Q = 0"
	},
	{
		title: "Bianchi",
		tex: "dH = 0,   dF_Q = 0"
	},
	{
		title: "Exchange",
		tex: "∇_μ T_m^{μν} = T_m ∇^ν ln A"
	}
];
var LIMITS = [
	"minimal",
	"gr",
	"local-only",
	"topo-only",
	"no-conformal",
	"frozen-y"
];
function ActionPage() {
	const lab = useLab();
	const [sample, setSample] = (0, import_react.useState)({
		q: 0,
		iqMean: 0,
		iqMax: 0,
		hNorm: 0,
		phiRms: 0,
		sourceJ: 0,
		aMean: 1
	});
	const aQ = alphaQ(lab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "RTCH master action" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Fully variational field system"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Diffeomorphism-invariant field theory on (M, g) with scalar φ, thermodynamic map Y^A : M → 𝒯, and two-form B. ω is closed and cohomologically nontrivial — it is not d(dℳ), because d² = 0."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Formula, {
				boxed: true,
				children: [
					"S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", {
						className: "font-sans text-sm not-italic",
						children: "RTCH"
					}),
					" = S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "EH" }),
					" + S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "φ" }),
					" + S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "Y" }),
					" + S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "B" }),
					" + S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "top" }),
					" + S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "m" }),
					" + S",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sub", { children: "GHY" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "λ_Q",
						value: lab.lambdaQ.toFixed(2),
						hint: lab.topologyOn ? "topological source" : "off"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "β_Q",
						value: lab.betaQ.toFixed(2),
						hint: "local coupling"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "α_Q",
						value: aQ.toFixed(3),
						hint: "β_Q / Λ_Q⁴"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "⟨A⟩",
						value: sample.aMean.toFixed(3),
						hint: "matter conformal factor"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "F_Q on a two-cycle · 𝒥_Q heatmap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono text-[10px] text-muted",
						children: [
							"Q ≈ ",
							sample.q.toFixed(2),
							" · ⟨𝒥_Q⟩ ",
							sample.iqMean.toFixed(3)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {
					params: lab,
					onSample: setSample,
					className: "h-[min(42vh,360px)] w-full"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: TERMS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] uppercase tracking-[0.16em] text-steel",
								children: t.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: t.status === "established" ? "ok" : "warn",
								children: t.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-xl tracking-tight",
							children: t.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: t.body
						})
					]
				}, t.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl tracking-tight",
							children: "Parameters"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "λ_Q",
							value: lab.lambdaQ,
							min: 0,
							max: 2,
							onChange: (v) => lab.set({ lambdaQ: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "β_Q",
							value: lab.betaQ,
							min: 0,
							max: 1.2,
							onChange: (v) => lab.set({ betaQ: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "Λ_Q",
							value: lab.lambdaScale,
							min: .4,
							max: 2,
							onChange: (v) => lab.set({ lambdaScale: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "winding n",
							value: lab.windingU,
							min: 1,
							max: 4,
							step: 1,
							onChange: (v) => lab.set({ windingU: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
							label: "winding m",
							value: lab.windingV,
							min: 1,
							max: 4,
							step: 1,
							onChange: (v) => lab.set({ windingV: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Topology on"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: lab.topologyOn,
								onCheckedChange: (v) => lab.set({ topologyOn: v })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Conformal A"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: lab.conformalOn,
								onCheckedChange: (v) => lab.set({ conformalOn: v })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl tracking-tight",
					children: "Euler–Lagrange"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-3",
					children: EQUATIONS.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-elevated px-4 py-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
							children: e.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 font-display text-lg tracking-tight",
							children: e.tex
						})]
					}, e.title))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl tracking-tight",
				children: "Limits"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-3",
				children: LIMITS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => lab.applyLimit(id),
					className: "rounded-lg bg-elevated px-3 py-3 text-left shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-[10px] text-steel",
						children: LIMIT_META[id].pair
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm",
						children: LIMIT_META[id].label
					})]
				}, id))
			})] })
		]
	});
}
function Knob({ label, value, min, max, step = .01, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex items-center justify-between font-mono text-[11px] text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums text-fg",
			children: Number.isInteger(step) ? String(value) : value.toFixed(2)
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
		min,
		max,
		step,
		value: [value],
		onValueChange: (v) => onChange(v[0] ?? value)
	})] });
}
//#endregion
export { ActionPage as component };
