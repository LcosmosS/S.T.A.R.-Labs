import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as getCatalog, T as mulberry32, b as INTRINSIC_NAMES, v as Button, w as intrinsicFeatures } from "./router-Cu8J75Dn.mjs";
import { r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/experiment-BMsA8Gj4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BarcodeCanvas({ intervals, className }) {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const draw = () => {
			const r = wrap.getBoundingClientRect();
			canvas.width = Math.max(1, Math.floor(r.width * dpr));
			canvas.height = Math.max(1, Math.floor(r.height * dpr));
			canvas.style.width = `${r.width}px`;
			canvas.style.height = `${r.height}px`;
			const w = canvas.width;
			const h = canvas.height;
			ctx.fillStyle = "#111318";
			ctx.fillRect(0, 0, w, h);
			const bars = intervals.slice(0, 18);
			const maxD = Math.max(.001, ...bars.map((b) => b.death));
			const pad = 16 * dpr;
			const row = (h - pad * 2) / Math.max(1, bars.length);
			bars.forEach((b, i) => {
				const y = pad + i * row + row * .25;
				const x0 = pad;
				const x1 = pad + b.death / maxD * (w - pad * 2);
				ctx.fillStyle = "rgba(138,160,181,0.85)";
				ctx.fillRect(x0, y, Math.max(2 * dpr, x1 - x0), row * .45);
			});
			ctx.fillStyle = "#8b919c";
			ctx.font = `${10 * dpr}px "IBM Plex Mono"`;
			ctx.fillText("H0 barcode  ·  birth = 0", pad, h - 6 * dpr);
		};
		draw();
		const ro = new ResizeObserver(draw);
		ro.observe(wrap);
		return () => ro.disconnect();
	}, [intervals]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block size-full"
		})
	});
}
function PcaCanvas({ points, className }) {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const draw = () => {
			const r = wrap.getBoundingClientRect();
			canvas.width = Math.max(1, Math.floor(r.width * dpr));
			canvas.height = Math.max(1, Math.floor(r.height * dpr));
			canvas.style.width = `${r.width}px`;
			canvas.style.height = `${r.height}px`;
			const w = canvas.width;
			const h = canvas.height;
			ctx.fillStyle = "#111318";
			ctx.fillRect(0, 0, w, h);
			let xmin = Infinity;
			let xmax = -Infinity;
			let ymin = Infinity;
			let ymax = -Infinity;
			for (const p of points) {
				xmin = Math.min(xmin, p.x);
				xmax = Math.max(xmax, p.x);
				ymin = Math.min(ymin, p.y);
				ymax = Math.max(ymax, p.y);
			}
			const dx = xmax - xmin || 1;
			const dy = ymax - ymin || 1;
			const pad = 18 * dpr;
			for (const p of points) {
				const x = pad + (p.x - xmin) / dx * (w - pad * 2);
				const y = pad + (p.y - ymin) / dy * (h - pad * 2);
				const lum = 140 + p.rank * 22;
				ctx.beginPath();
				ctx.arc(x, y, (2 + p.rank * .6) * dpr, 0, Math.PI * 2);
				ctx.fillStyle = `rgba(${lum - 30},${lum},${lum + 20},0.9)`;
				ctx.fill();
			}
			ctx.fillStyle = "#8b919c";
			ctx.font = `${10 * dpr}px "IBM Plex Mono"`;
			ctx.fillText("PCA of intrinsic features  ·  rank held out", pad, h - 6 * dpr);
		};
		draw();
		const ro = new ResizeObserver(draw);
		ro.observe(wrap);
		return () => ro.disconnect();
	}, [points]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block size-full"
		})
	});
}
function robustScale(X) {
	const d = X[0]?.length ?? 0;
	const n = X.length;
	const med = [];
	const iqr = [];
	for (let j = 0; j < d; j++) {
		const col = X.map((r) => r[j]).sort((a, b) => a - b);
		const q = (p) => {
			const i = (n - 1) * p;
			const lo = Math.floor(i);
			const hi = Math.ceil(i);
			return col[lo] + (col[hi] - col[lo]) * (i - lo);
		};
		const m = q(.5);
		const s = q(.9) - q(.1);
		med.push(m);
		iqr.push(s < 1e-9 ? 1 : s);
	}
	return X.map((row) => row.map((v, j) => (v - med[j]) / iqr[j]));
}
function dist2(a, b) {
	let s = 0;
	for (let i = 0; i < a.length; i++) {
		const d = a[i] - b[i];
		s += d * d;
	}
	return s;
}
var UnionFind = class {
	parent;
	rank;
	constructor(n) {
		this.parent = new Int32Array(n);
		this.rank = new Int32Array(n);
		for (let i = 0; i < n; i++) this.parent[i] = i;
	}
	find(i) {
		let p = i;
		while (this.parent[p] !== p) {
			this.parent[p] = this.parent[this.parent[p]];
			p = this.parent[p];
		}
		return p;
	}
	union(a, b) {
		let ra = this.find(a);
		let rb = this.find(b);
		if (ra === rb) return false;
		if (this.rank[ra] < this.rank[rb]) [ra, rb] = [rb, ra];
		this.parent[rb] = ra;
		if (this.rank[ra] === this.rank[rb]) this.rank[ra] += 1;
		return true;
	}
};
function h0FromPoints(X) {
	const n = X.length;
	const edges = [];
	for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) edges.push({
		i,
		j,
		d: Math.sqrt(dist2(X[i], X[j]))
	});
	edges.sort((a, b) => a.d - b.d);
	const uf = new UnionFind(n);
	const intervals = [];
	for (const e of edges) if (uf.union(e.i, e.j)) {
		intervals.push({
			dim: 0,
			birth: 0,
			death: e.d,
			persistence: e.d
		});
		if (intervals.length === n - 1) break;
	}
	return intervals;
}
function knnGraph(X, k) {
	const n = X.length;
	const adj = Array.from({ length: n }, () => []);
	const w = Array.from({ length: n }, () => []);
	const seen = /* @__PURE__ */ new Set();
	for (let i = 0; i < n; i++) {
		const ds = [];
		for (let j = 0; j < n; j++) {
			if (i === j) continue;
			ds.push({
				j,
				d: Math.sqrt(dist2(X[i], X[j]))
			});
		}
		ds.sort((a, b) => a.d - b.d);
		for (let t = 0; t < k && t < ds.length; t++) {
			const j = ds[t].j;
			const key = i < j ? `${i}-${j}` : `${j}-${i}`;
			if (seen.has(key)) continue;
			seen.add(key);
			adj[i].push(j);
			adj[j].push(i);
			w[i].push(ds[t].d);
			w[j].push(ds[t].d);
		}
	}
	const uf = new UnionFind(n);
	const cycleBirths = [];
	const edgeList = [];
	for (let i = 0; i < n; i++) for (let t = 0; t < adj[i].length; t++) {
		const j = adj[i][t];
		if (i < j) edgeList.push({
			i,
			j,
			d: w[i][t]
		});
	}
	edgeList.sort((a, b) => a.d - b.d);
	let tree = 0;
	for (const e of edgeList) if (uf.union(e.i, e.j)) tree += 1;
	else cycleBirths.push(e.d);
	const roots = /* @__PURE__ */ new Set();
	for (let i = 0; i < n; i++) roots.add(uf.find(i));
	const components = roots.size;
	const edges = edgeList.length;
	return {
		adj,
		w,
		edges,
		components,
		betti1: Math.max(0, edges - n + components),
		cycleBirths
	};
}
function dijkstra(graph, src) {
	const n = graph.adj.length;
	const dist = new Float64Array(n);
	dist.fill(Infinity);
	dist[src] = 0;
	const used = new Uint8Array(n);
	for (let iter = 0; iter < n; iter++) {
		let u = -1;
		let best = Infinity;
		for (let i = 0; i < n; i++) if (!used[i] && dist[i] < best) {
			best = dist[i];
			u = i;
		}
		if (u < 0) break;
		used[u] = 1;
		const nbr = graph.adj[u];
		for (let t = 0; t < nbr.length; t++) {
			const v = nbr[t];
			const nd = dist[u] + graph.w[u][t];
			if (nd < dist[v]) dist[v] = nd;
		}
	}
	return dist;
}
function geodesicSample(X, graph, nPairs, rng) {
	const n = X.length;
	const pairs = [];
	const neighbor = /* @__PURE__ */ new Set();
	for (let i = 0; i < n; i++) for (const j of graph.adj[i]) neighbor.add(i < j ? `${i}-${j}` : `${j}-${i}`);
	let tries = 0;
	while (pairs.length < nPairs && tries < nPairs * 40) {
		tries += 1;
		const i = Math.floor(rng() * n);
		const j = Math.floor(rng() * n);
		if (i === j) continue;
		const key = i < j ? `${i}-${j}` : `${j}-${i}`;
		if (neighbor.has(key)) continue;
		const g = dijkstra(graph, i)[j];
		if (!Number.isFinite(g) || g <= 0) continue;
		const chord = Math.sqrt(dist2(X[i], X[j]));
		if (chord < 1e-9) continue;
		pairs.push({
			i,
			j,
			graph: g,
			chord,
			tortuosity: g / chord
		});
	}
	return pairs;
}
function pca2(X) {
	const n = X.length;
	const d = X[0]?.length ?? 0;
	const mean = new Array(d).fill(0);
	for (const row of X) for (let j = 0; j < d; j++) mean[j] += row[j];
	for (let j = 0; j < d; j++) mean[j] /= n;
	const C = Array.from({ length: d }, () => new Array(d).fill(0));
	for (const row of X) for (let a = 0; a < d; a++) for (let b = 0; b < d; b++) C[a][b] += (row[a] - mean[a]) * (row[b] - mean[b]);
	for (let a = 0; a < d; a++) for (let b = 0; b < d; b++) C[a][b] /= Math.max(1, n - 1);
	function power(mat, iters = 40) {
		let v = new Array(d).fill(0).map((_, i) => i === 0 ? 1 : .07 * i);
		let norm = Math.hypot(...v) || 1;
		v = v.map((x) => x / norm);
		for (let t = 0; t < iters; t++) {
			const nv = new Array(d).fill(0);
			for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) nv[i] += mat[i][j] * v[j];
			norm = Math.hypot(...nv) || 1;
			v = nv.map((x) => x / norm);
		}
		return v;
	}
	const v1 = power(C);
	const v2 = power(C.map((row, i) => row.map((c, j) => {
		let dot = 0;
		for (let k = 0; k < d; k++) for (let l = 0; l < d; l++) dot += v1[k] * C[k][l] * v1[l];
		return c - dot * v1[i] * v1[j];
	})));
	return X.map((row) => {
		let x = 0;
		let y = 0;
		for (let j = 0; j < d; j++) {
			const z = row[j] - mean[j];
			x += z * v1[j];
			y += z * v2[j];
		}
		return {
			x,
			y
		};
	});
}
function permuteColumns(X, rng) {
	const n = X.length;
	const d = X[0]?.length ?? 0;
	const out = X.map((r) => r.slice());
	for (let j = 0; j < d; j++) for (let i = n - 1; i > 0; i--) {
		const k = Math.floor(rng() * (i + 1));
		const tmp = out[i][j];
		out[i][j] = out[k][j];
		out[k][j] = tmp;
	}
	return out;
}
function stats(samples, observed) {
	const n = samples.length;
	const mean = samples.reduce((a, b) => a + b, 0) / Math.max(1, n);
	const var_ = samples.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(1, n - 1);
	return {
		mean,
		std: Math.sqrt(var_),
		p: (samples.filter((s) => s >= observed).length + 1) / (n + 1),
		samples
	};
}
function torusSample(n, rng) {
	const R = 2;
	const r = 1;
	const pts = [];
	for (let i = 0; i < n; i++) {
		const u = rng() * Math.PI * 2;
		const v = rng() * Math.PI * 2;
		pts.push([
			(R + r * Math.cos(v)) * Math.cos(u),
			(R + r * Math.cos(v)) * Math.sin(u),
			r * Math.sin(v),
			.15 * Math.sin(2 * u),
			.15 * Math.cos(3 * v)
		]);
	}
	return pts;
}
function matrixFromCurves(curves) {
	return {
		X: robustScale(curves.map(intrinsicFeatures)),
		labels: curves.map((c) => c.label),
		ranks: curves.map((c) => c.rank)
	};
}
function summarize(X, k, nPairs, rng) {
	const intervals = h0FromPoints(X);
	const graph = knnGraph(X, k);
	const pairs = geodesicSample(X, graph, nPairs, rng);
	const torts = pairs.map((p) => p.tortuosity);
	const meanTort = torts.length ? torts.reduce((a, b) => a + b, 0) / torts.length : 1;
	const sorted = torts.slice().sort((a, b) => a - b);
	return {
		intervals,
		graph,
		pairs,
		meanTort,
		medianTort: sorted.length ? sorted[Math.floor(sorted.length / 2)] : 1,
		h0Max: intervals.reduce((m, iv) => Math.max(m, iv.persistence), 0),
		h0Mean: intervals.length ? intervals.reduce((s, iv) => s + iv.persistence, 0) / intervals.length : 0
	};
}
function runExperiment(opts) {
	const nNulls = opts.nNulls ?? 24;
	const k = opts.k ?? 8;
	const seed = opts.seed ?? 20260917;
	const nPairs = opts.nPairs ?? 40;
	const rng = mulberry32(seed);
	const curves = getCatalog();
	let X;
	let labels;
	let ranks;
	if (opts.kind === "torus") {
		X = robustScale(torusSample(Math.min(220, curves.length), rng));
		labels = X.map((_, i) => `T${i}`);
		ranks = X.map(() => 0);
	} else {
		const m = matrixFromCurves(curves);
		X = m.X;
		labels = m.labels;
		ranks = m.ranks;
		if (opts.kind === "scrambled") X = permuteColumns(X, rng);
	}
	const obs = summarize(X, k, nPairs, rng);
	const pcaCoords = pca2(X);
	const nullH0s = [];
	const nullB1 = [];
	const nullT = [];
	for (let n = 0; n < nNulls; n++) {
		const s = summarize(permuteColumns(X, rng), k, Math.min(16, nPairs), rng);
		nullH0s.push(s.h0Max);
		nullB1.push(s.graph.betti1);
		nullT.push(s.meanTort);
	}
	const nullH0 = stats(nullH0s, obs.h0Max);
	const nullBetti = stats(nullB1, obs.graph.betti1);
	const nullTort = stats(nullT, obs.meanTort);
	const survive = opts.kind === "torus" ? obs.graph.betti1 >= 2 : nullH0.p < .05 || nullBetti.p < .05;
	const verdict = opts.kind === "torus" ? obs.graph.betti1 >= 2 ? "Positive control: the sampled torus retains extra 1-cycles in its kNN graph, as required." : "Positive control failed — increase sample size or k. A sparse kNN graph is not a VR complex." : opts.kind === "scrambled" ? "Scrambled columns destroy joint structure. This is the N1 null geometry itself." : survive ? "Observed topology exceeds the N1 column-permutation null at α = 0.05 on at least one statistic. This is evidence of structure in the sampled metric, not a proof that T is a manifold with H^k ≠ 0." : "Observed topology is statistically indistinguishable from the N1 null at this sample size. A null result is scientifically useful.";
	return {
		kind: opts.kind,
		n: X.length,
		features: INTRINSIC_NAMES,
		seed,
		nNulls,
		k,
		intervals: obs.intervals.slice().sort((a, b) => b.persistence - a.persistence).slice(0, 24),
		h0Max: obs.h0Max,
		h0Mean: obs.h0Mean,
		betti1: obs.graph.betti1,
		cycleBirths: obs.graph.cycleBirths.slice(0, 24),
		geodesic: {
			meanTort: obs.meanTort,
			medianTort: obs.medianTort,
			pairs: obs.pairs.slice(0, 8)
		},
		pca: pcaCoords.map((p, i) => ({
			...p,
			rank: ranks[i] ?? 0,
			label: labels[i] ?? String(i)
		})),
		nullH0,
		nullBetti,
		nullTort,
		verdict,
		caveats: [
			"Persistent H_k of a finite point cloud is not a proof that the arithmetic state space is a smooth manifold.",
			"Rank is excluded from the primary feature metric (RTCH-E1 protocol).",
			"Graph Betti-1 is computed on a kNN graph, not a complete Vietoris–Rips complex.",
			"N1 independently permutes each feature column, preserving every marginal."
		]
	};
}
function ExperimentPage() {
	const [kind, setKind] = (0, import_react.useState)("catalog");
	const [version, setVersion] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const result = (0, import_react.useMemo)(() => {
		return runExperiment({
			kind,
			nNulls: 18,
			k: 8,
			nPairs: 28,
			seed: 20260917 + version
		});
	}, [kind, version]);
	function rerun(next) {
		setBusy(true);
		setKind(next);
		setVersion((v) => v + 1);
		requestAnimationFrame(() => setBusy(false));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "steel",
						children: "RTCH-E1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Arithmetic–geodesic–cohomological test"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "A persistent feature of a finite point cloud is evidence at a scale — not a proof that the arithmetic state space is a manifold with H^k ≠ 0. Rank is held out of the metric. Structure is compared to N1: independent column permutation, preserving every marginal."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: kind === "catalog" ? "default" : "secondary",
						onClick: () => rerun("catalog"),
						children: "Catalog"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: kind === "torus" ? "default" : "secondary",
						onClick: () => rerun("torus"),
						children: "Torus control"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: kind === "scrambled" ? "default" : "secondary",
						onClick: () => rerun("scrambled"),
						children: "N1 scramble"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Verdict, {
				result,
				busy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "n",
						value: String(result.n),
						hint: `${result.features.length} features`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "H0 max pers.",
						value: result.h0Max.toFixed(3),
						hint: `p = ${result.nullH0.p.toFixed(3)} vs N1`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "kNN β₁",
						value: String(result.betti1),
						hint: `p = ${result.nullBetti.p.toFixed(3)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "⟨tortuosity⟩",
						value: result.geodesic.meanTort.toFixed(3),
						hint: `p = ${result.nullTort.p.toFixed(3)}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "H0 persistence"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BarcodeCanvas, {
						intervals: result.intervals,
						className: "h-56 w-full"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Scalar embedding"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PcaCanvas, {
						points: result.pca,
						className: "h-56 w-full"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl tracking-tight",
						children: "Null protocol"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "N1 — independently permute each intrinsic column." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Primary features: log N, sgn log |Δ|, log |j|, Faltings height, log R." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Graph geodesics exclude direct kNN neighbors, so reported tortuosity is a multi-edge path." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Positive control uses a sampled torus in R³, not Fibonacci or golden-ratio maps." })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl tracking-tight",
						children: "Geodesic sample"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left font-mono text-[11px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-subtle",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 pr-3",
										children: "i"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 pr-3",
										children: "j"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 pr-3",
										children: "graph"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 pr-3",
										children: "chord"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "τ"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: result.geodesic.pairs.slice(0, 6).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-fg",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-3 tabular-nums",
										children: p.i
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-3 tabular-nums",
										children: p.j
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-3 tabular-nums",
										children: p.graph.toFixed(3)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-3 tabular-nums",
										children: p.chord.toFixed(3)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 tabular-nums",
										children: p.tortuosity.toFixed(3)
									})
								]
							}, `${p.i}-${p.j}`)) })]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl tracking-tight",
				children: "Caveats"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 max-w-2xl space-y-2 text-sm leading-relaxed text-muted",
				children: result.caveats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: c }, c))
			})] })
		]
	});
}
function Verdict({ result, busy }) {
	const tone = result.kind === "torus" ? "ok" : result.nullH0.p < .05 || result.nullBetti.p < .05 ? "warn" : "default";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				tone,
				children: result.kind
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
				children: [
					result.nNulls,
					" nulls · k = ",
					result.k,
					busy ? " · running" : ""
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-relaxed text-fg",
			children: result.verdict
		})]
	});
}
//#endregion
export { ExperimentPage as component };
