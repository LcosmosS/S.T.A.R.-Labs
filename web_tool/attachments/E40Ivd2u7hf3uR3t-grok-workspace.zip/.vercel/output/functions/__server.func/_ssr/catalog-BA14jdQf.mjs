import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as getCatalog, S as catalogStats, r as useLab } from "./router-Cu8J75Dn.mjs";
import { r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-BA14jdQf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-elevated px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-ring/70", className),
		...props
	});
}
function CatalogPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [rank, setRank] = (0, import_react.useState)("all");
	const selected = useLab((s) => s.selectedLabel);
	const set = useLab((s) => s.set);
	const curves = getCatalog();
	const stats = catalogStats();
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return curves.filter((c) => {
			if (rank !== "all" && c.rank !== rank) return false;
			if (!query) return true;
			return c.label.toLowerCase().includes(query) || String(c.conductor).includes(query) || c.torsion.toLowerCase().includes(query);
		});
	}, [
		curves,
		q,
		rank
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "LMFDB-style seed" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Elliptic-curve catalog"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Named curves keep their LMFDB labels. The remainder is a synthetic, seeded draw used so the projection and RTCH-E1 pipeline can run entirely in the browser. Rank is a response variable — never part of the primary topology metric."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Curves",
						value: String(stats.n),
						hint: `${stats.famous} named`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Rank 0 / 1",
						value: `${stats.ranks[0]} / ${stats.ranks[1]}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Rank 2+",
						value: String(stats.ranks[2] + stats.ranks[3] + stats.ranks[4])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "⟨Ω_E⟩",
						value: stats.meanOmega.toFixed(3)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search label, conductor, torsion",
					"aria-label": "Search catalog"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1",
					children: [
						"all",
						0,
						1,
						2,
						3,
						4
					].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setRank(r),
						className: `h-11 rounded-md px-3 text-sm ${rank === r ? "bg-primary text-primary-fg" : "bg-elevated text-muted shadow-[var(--shadow-border)]"}`,
						children: r === "all" ? "All ranks" : `r = ${r}`
					}, String(r)))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Label"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "N"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "r"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "R"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "Ω"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "Δ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "Tors"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: "Src"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.slice(0, 80).map((c) => {
						const on = c.label === selected;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: `cursor-pointer border-t border-border ${on ? "bg-elevated" : "hover:bg-elevated/60"}`,
							onClick: () => set({ selectedLabel: c.label }),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 font-mono text-fg",
									children: c.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-mono tabular-nums text-muted",
									children: c.conductor
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-mono tabular-nums",
									children: c.rank
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-mono tabular-nums text-muted",
									children: c.regulator.toFixed(4)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-mono tabular-nums",
									children: c.omega.toFixed(4)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-mono tabular-nums text-muted",
									children: c.disc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-mono text-muted",
									children: c.torsion
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: c.provenance === "lmfdb" ? "ok" : "default",
										children: c.provenance
									})
								})
							]
						}, c.label);
					}) })]
				}), rows.length > 80 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border px-4 py-3 font-mono text-[11px] text-subtle",
					children: [
						"Showing 80 of ",
						rows.length,
						" matches"
					]
				}) : null]
			})
		]
	});
}
//#endregion
export { CatalogPage as component };
