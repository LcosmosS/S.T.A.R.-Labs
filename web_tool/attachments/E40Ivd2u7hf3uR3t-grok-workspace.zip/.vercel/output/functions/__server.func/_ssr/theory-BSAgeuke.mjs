import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Formula, t as Badge } from "./formula-ICCwus6g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/theory-BSAgeuke.js
var import_jsx_runtime = require_jsx_runtime();
var CHAIN = [
	{
		title: "State map",
		body: "Φ : M → 𝒯, x ↦ Y^A(x)"
	},
	{
		title: "Pullback",
		body: "F_Q = Φ* ω,  d F_Q = 0"
	},
	{
		title: "Local scalar",
		body: "𝒥_Q = ¼ F_Q²  (not Q_RTCH)"
	},
	{
		title: "Conformal factor",
		body: "A = A(φ, ℳ, 𝒥_Q) > 0"
	},
	{
		title: "Physical metric",
		body: "g̃_μν = A² g_μν"
	},
	{
		title: "Matter action",
		body: "S_m[Ψ_m, g̃]"
	},
	{
		title: "Both regimes",
		body: "particles, fluids, T_m, exchange"
	}
];
var LIMITS = [
	{
		title: "Candidate action",
		body: "The master action is a variational realization, not a uniqueness theorem."
	},
	{
		title: "Nontrivial class",
		body: "Existence of closed non-exact ω is an assumption on 𝒯."
	},
	{
		title: "Choice of 𝒥_Q",
		body: "¼ F² is a chosen local invariant among several possible scalars."
	},
	{
		title: "A(φ, ℳ, 𝒥_Q)",
		body: "The conformal coupling is additional model structure."
	},
	{
		title: "Two-form B",
		body: "Introduces extra dynamical degrees of freedom."
	},
	{
		title: "No entropy production",
		body: "A conservative action does not automatically describe irreversible processes."
	},
	{
		title: "Arithmetic ≠ thermodynamic",
		body: "Y^A(E) does not by itself identify rank with mass or conductor with energy."
	},
	{
		title: "Open empirics",
		body: "Local coupling remains untested until a map from observables to (φ, ℳ, F_Q) is specified."
	}
];
function TheoryPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Status of claims" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Established geometry, conjectural physics"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "The RTCH paper is explicit: conformal matter coupling and closed-form pullbacks are differential geometry. Identifying elliptic-curve invariants with thermodynamic fields, and asserting that A depends on 𝒥_Q, are conjectural until constrained against nested nulls."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: "Structural chain"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: CHAIN.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-[10px] uppercase tracking-[0.16em] text-steel",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-xl tracking-tight",
							children: c.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-fg",
							children: c.body
						})
					]
				}, c.title))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Formula, {
				boxed: true,
				children: "H₀ : β_Q = 0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "ok",
						children: "Established"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pullback of a closed form is closed." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Matter coupled to g̃ = A² g has diffeomorphism-invariant conservation in the physical frame." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Worldline variation of −m ∫ A ds yields a^ν = −c² h^νμ ∇_μ ln A." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The dust limit of the Euler equation reproduces that worldline force." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "u_μ f^μ = 0, so four-velocity normalization is preserved." })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "warn",
						children: "Conjectural / ECC / ACSC"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Nontrivial [ω] ∈ H²(𝒯) with thermodynamic interpretation." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A depends on 𝒥_Q rather than another invariant of F_Q." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Y^A built from (log N, log |Δ|, r, log R, log |Ω|, …)." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Scale-dependent H_eff from period weighting." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Arithmetic projection as a source of large-scale structure." })
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: "Limitations (paper §53)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: LIMITS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg tracking-tight",
						children: l.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: l.body
					})]
				}, l.title))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "What would count"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: "A meaningful RTCH-E1 result is a stable H1/H2 signature longer than matched nulls, surviving seeds, feature subsets, and isogeny-class controls, with geodesic or scalar coordinates that predict a held-out invariant. Even then it is structure in a chosen metric representation — not a physical law. Falsification is equally useful: persistence indistinguishable from N1, or topology explained by a single marginal."
				})]
			})
		]
	});
}
//#endregion
export { TheoryPage as component };
