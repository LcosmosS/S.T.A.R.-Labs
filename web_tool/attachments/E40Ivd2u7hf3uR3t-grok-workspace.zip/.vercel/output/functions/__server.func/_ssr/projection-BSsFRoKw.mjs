import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as catalogStats, i as FILAMENTS, r as useLab, s as PROJECTED } from "./router-Cu8J75Dn.mjs";
import { n as Formula, r as Metric, t as Badge } from "./formula-ICCwus6g.mjs";
import { t as OrbitCloud } from "./orbit-cloud-CutwTzrs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projection-BSsFRoKw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EntropyField({ points, className }) {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const draw = () => {
			const r = wrap.getBoundingClientRect();
			canvas.width = Math.max(1, Math.floor(r.width * dpr));
			canvas.height = Math.max(1, Math.floor(r.height * dpr));
			canvas.style.width = `${r.width}px`;
			canvas.style.height = `${r.height}px`;
			const w = canvas.width;
			const h = canvas.height;
			const W = 90;
			const H = 70;
			const img = ctx.createImageData(W, H);
			let max = 0;
			const field = /* @__PURE__ */ new Float32Array(6300);
			for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
				const px = x / 89 * 2 - 1;
				const py = y / 69 * 2 - 1;
				let v = 0;
				for (const p of points) {
					const dx = px - p.x * .55;
					const dy = py - p.y * .55;
					const s = .08 + .02 * p.rank;
					v += p.entropy * Math.exp(-(dx * dx + dy * dy) / (2 * s * s));
				}
				field[y * W + x] = v;
				if (v > max) max = v;
			}
			let k = 0;
			for (let i = 0; i < field.length; i++) {
				const t = field[i] / (max + 1e-6);
				img.data[k++] = Math.floor(12 + 30 * t);
				img.data[k++] = Math.floor(16 + 70 * t);
				img.data[k++] = Math.floor(22 + 140 * t);
				img.data[k++] = 255;
			}
			const off = document.createElement("canvas");
			off.width = W;
			off.height = H;
			off.getContext("2d")?.putImageData(img, 0, 0);
			ctx.imageSmoothingEnabled = true;
			ctx.drawImage(off, 0, 0, w, h);
			ctx.fillStyle = "rgba(236,238,242,0.8)";
			for (const p of points) {
				if (p.rank < 2) continue;
				const x = (p.x * .55 + 1) / 2 * w;
				const y = (p.y * .55 + 1) / 2 * h;
				ctx.beginPath();
				ctx.arc(x, y, 2.2 * dpr, 0, Math.PI * 2);
				ctx.fill();
			}
		};
		draw();
		const ro = new ResizeObserver(draw);
		ro.observe(wrap);
		return () => ro.disconnect();
	}, [points]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block size-full"
		})
	});
}
function ProjectionPage() {
	const selected = useLab((s) => s.selectedLabel);
	const set = useLab((s) => s.set);
	const stats = catalogStats();
	const curve = PROJECTED.find((c) => c.label === selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "warn",
						children: "ACSC · conjectural map"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Arithmetic projection Φ(E)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Elliptic-curve invariants are placed on a 3-manifold by a density-equalizing map of log-conductor, with rank as a mild offset. The RTCH paper is careful: this does not establish that those invariants are thermodynamic fields. It supplies a possible Y^A(E) on which the cohomological machinery can act."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Formula, {
				boxed: true,
				children: "Y^A ∼ (log N_E, log |Δ_E|, r_E, log R_E, log |Ω_E|, …)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Points",
						value: String(PROJECTED.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Filaments",
						value: String(FILAMENTS.length),
						hint: "3-NN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "⟨entropy⟩",
						value: stats.meanEntropy.toFixed(2),
						hint: "log |Δ|"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
					children: "Φ(E) point cloud"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitCloud, {
					points: PROJECTED,
					links: FILAMENTS,
					selected,
					onSelect: (label) => set({ selectedLabel: label }),
					className: "h-[min(52vh,440px)] w-full"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
						children: "Entropy density"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntropyField, {
						points: PROJECTED,
						className: "h-56 w-full sm:h-72"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl tracking-tight",
						children: curve?.label ?? "Select a curve"
					}), curve ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "conductor N",
								v: String(curve.conductor)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "rank",
								v: String(curve.rank)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "regulator",
								v: curve.regulator.toFixed(5)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "real period Ω",
								v: curve.omega.toFixed(5)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "discriminant",
								v: String(curve.disc)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "Faltings h",
								v: curve.faltingsHeight.toFixed(3)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "torsion",
								v: curve.torsion
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
								k: "isogeny",
								v: curve.isogeny
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Click a point in the cloud."
					})]
				})]
			})
		]
	});
}
function Item({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "font-mono text-[10px] uppercase tracking-[0.14em] text-subtle",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "font-mono tabular-nums text-fg",
		children: v
	})] });
}
//#endregion
export { ProjectionPage as component };
