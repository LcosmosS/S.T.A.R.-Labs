import { i as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_react, r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Orbit, c as FlaskConical, d as Atom, i as Table2, l as Compass, n as Waves, o as Menu, p as Activity, r as TriangleAlert, s as Hexagon, t as X, u as BookOpen } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTrigger, r as DialogContent, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-D3w04iTt.js
function mulberry32(seed) {
	let a = seed >>> 0;
	return function next() {
		a += 1831565813;
		let t = a;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function hash32(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
/** Illustrative LMFDB/Cremona labels used as the ACSC projection seed. */
var FAMOUS = [
	{
		label: "11.a3",
		conductor: 11,
		rank: 0,
		regulator: 1,
		omega: 6.34605,
		disc: -11,
		jinv: -122023936 / 161051,
		faltingsHeight: -1.21,
		ainvs: [
			0,
			-1,
			1,
			0,
			0
		],
		torsion: "Z/5",
		isogeny: "11.a",
		provenance: "lmfdb"
	},
	{
		label: "11.a2",
		conductor: 11,
		rank: 0,
		regulator: 1,
		omega: 1.26921,
		disc: -161051,
		jinv: -122023936 / 161051,
		faltingsHeight: .42,
		ainvs: [
			0,
			-1,
			1,
			-10,
			-20
		],
		torsion: "Z/5",
		isogeny: "11.a",
		provenance: "lmfdb"
	},
	{
		label: "11.a1",
		conductor: 11,
		rank: 0,
		regulator: 1,
		omega: .25384,
		disc: 11,
		jinv: -122023936 / 161051,
		faltingsHeight: 1.87,
		ainvs: [
			0,
			-1,
			1,
			-7820,
			-263580
		],
		torsion: "Z/5",
		isogeny: "11.a",
		provenance: "lmfdb"
	},
	{
		label: "37.a1",
		conductor: 37,
		rank: 1,
		regulator: .05111,
		omega: 5.98692,
		disc: -37,
		jinv: 110592 / 37,
		faltingsHeight: -.18,
		ainvs: [
			0,
			0,
			1,
			-1,
			0
		],
		torsion: "1",
		isogeny: "37.a",
		provenance: "lmfdb"
	},
	{
		label: "43.a1",
		conductor: 43,
		rank: 1,
		regulator: .03248,
		omega: 5.47113,
		disc: -43,
		jinv: 4096 / 43,
		faltingsHeight: -.09,
		ainvs: [
			0,
			1,
			1,
			0,
			0
		],
		torsion: "1",
		isogeny: "43.a",
		provenance: "lmfdb"
	},
	{
		label: "53.a1",
		conductor: 53,
		rank: 1,
		regulator: .14298,
		omega: 4.87201,
		disc: -53,
		jinv: -16 / 53,
		faltingsHeight: .11,
		ainvs: [
			1,
			-1,
			1,
			0,
			0
		],
		torsion: "1",
		isogeny: "53.a",
		provenance: "lmfdb"
	},
	{
		label: "61.a1",
		conductor: 61,
		rank: 1,
		regulator: .04865,
		omega: 4.9812,
		disc: -61,
		jinv: 20736 / 61,
		faltingsHeight: -.05,
		ainvs: [
			1,
			0,
			0,
			-2,
			1
		],
		torsion: "1",
		isogeny: "61.a",
		provenance: "lmfdb"
	},
	{
		label: "89.a1",
		conductor: 89,
		rank: 1,
		regulator: .1723,
		omega: 4.2104,
		disc: -89,
		jinv: -1 / 89,
		faltingsHeight: .22,
		ainvs: [
			1,
			1,
			0,
			-2,
			0
		],
		torsion: "1",
		isogeny: "89.a",
		provenance: "lmfdb"
	},
	{
		label: "389.a1",
		conductor: 389,
		rank: 2,
		regulator: .15246,
		omega: 2.49014,
		disc: -389,
		jinv: -144 / 389,
		faltingsHeight: .54,
		ainvs: [
			0,
			1,
			1,
			-2,
			0
		],
		torsion: "1",
		isogeny: "389.a",
		provenance: "lmfdb"
	},
	{
		label: "433.a1",
		conductor: 433,
		rank: 2,
		regulator: .2341,
		omega: 2.3188,
		disc: -433,
		jinv: 1728 / 433,
		faltingsHeight: .61,
		ainvs: [
			1,
			-1,
			0,
			-3,
			2
		],
		torsion: "1",
		isogeny: "433.a",
		provenance: "lmfdb"
	},
	{
		label: "5077.a1",
		conductor: 5077,
		rank: 3,
		regulator: .4172,
		omega: 1.1024,
		disc: -5077,
		jinv: -1728 / 5077,
		faltingsHeight: 1.14,
		ainvs: [
			0,
			0,
			1,
			-7,
			6
		],
		torsion: "1",
		isogeny: "5077.a",
		provenance: "lmfdb"
	},
	{
		label: "234446.a1",
		conductor: 234446,
		rank: 4,
		regulator: 1.528,
		omega: .4122,
		disc: -234446,
		jinv: 0,
		faltingsHeight: 2.41,
		ainvs: [
			1,
			0,
			1,
			-36,
			-70
		],
		torsion: "1",
		isogeny: "234446.a",
		provenance: "lmfdb"
	}
];
function syntheticCurve(i, rng) {
	const roll = rng();
	const rank = roll < .38 ? 0 : roll < .86 ? 1 : roll < .97 ? 2 : roll < .995 ? 3 : 4;
	const conductor = Math.round(14 + rng() * rng() * 18e4);
	const letter = String.fromCharCode(97 + Math.floor(rng() * 6));
	const label = `${conductor}.${letter}1`;
	const regulator = rank === 0 ? 1 : Math.exp(.35 * rank * rng()) * rank * (.04 + .18 * rng()) * Math.log(conductor + 3);
	const omega = 6.8 / Math.pow(conductor, .22) * (.55 + .9 * rng()) / (1 + .18 * rank);
	const disc = (rng() < .55 ? -1 : 1) * Math.round(conductor * (1 + rng() * 40) * Math.pow(10, Math.floor(rng() * 3)));
	const torsionPool = [
		"1",
		"Z/2",
		"Z/2×Z/2",
		"Z/4",
		"Z/3",
		"Z/5",
		"Z/6"
	];
	const jinv = (rng() - .5) * Math.pow(10, 2 + rng() * 4);
	const faltingsHeight = Math.log(Math.abs(disc) + 3) * (.12 + .18 * rank) - 1.4 + rng();
	return {
		label,
		conductor,
		rank,
		regulator: Number(regulator.toFixed(5)),
		omega: Number(omega.toFixed(5)),
		disc,
		jinv: Number(jinv.toFixed(3)),
		faltingsHeight: Number(faltingsHeight.toFixed(4)),
		ainvs: [
			Math.floor(rng() * 3) - 1,
			Math.floor(rng() * 5) - 2,
			Math.floor(rng() * 2),
			Math.floor(rng() * 21) - 10,
			Math.floor(rng() * 41) - 20
		],
		torsion: torsionPool[Math.floor(rng() * torsionPool.length)] ?? "1",
		isogeny: `${conductor}.${letter}`,
		provenance: "synthetic"
	};
}
var cached = null;
function getCatalog() {
	if (cached) return cached;
	const rng = mulberry32(1398030674);
	const extra = [];
	const used = new Set(FAMOUS.map((c) => c.label));
	let i = 0;
	while (extra.length < 148) {
		const c = syntheticCurve(i++, rng);
		if (used.has(c.label)) continue;
		used.add(c.label);
		extra.push(c);
	}
	cached = [...FAMOUS, ...extra].sort((a, b) => a.conductor - b.conductor || a.label.localeCompare(b.label));
	return cached;
}
var CLUSTERS = [
	{
		name: "Virgo",
		rMly: 54,
		rank: 2,
		conductor: 182e8,
		hFactor: 1.0174,
		entropy: 35.15,
		cohClass: 12.63,
		volume: 3235e5,
		derivedA: -1706
	},
	{
		name: "Perseus",
		rMly: 236,
		rank: 1,
		conductor: 256e8,
		hFactor: 1.0237,
		entropy: 39.31,
		cohClass: 4.8,
		volume: 1313e6,
		derivedA: -7456
	},
	{
		name: "Coma",
		rMly: 321,
		rank: 0,
		conductor: 41e11,
		hFactor: 1.0251,
		entropy: 39.64,
		cohClass: 2.1,
		volume: 512e5,
		derivedA: -10141
	},
	{
		name: "Hercules",
		rMly: 500,
		rank: 1,
		conductor: 84e10,
		hFactor: 1.027,
		entropy: 40.12,
		cohClass: 3.41,
		volume: 208e6,
		derivedA: -15796
	},
	{
		name: "Shapley",
		rMly: 650,
		rank: 1,
		conductor: 11e11,
		hFactor: 1.0281,
		entropy: 40.55,
		cohClass: 3.02,
		volume: 441e6,
		derivedA: -20535
	}
];
var KAPPA_UCF = 31.5926;
function catalogStats(curves = getCatalog()) {
	const n = curves.length;
	const ranks = [
		0,
		0,
		0,
		0,
		0
	];
	let om = 0;
	let ent = 0;
	let famous = 0;
	for (const c of curves) {
		ranks[Math.min(c.rank, 4)] += 1;
		om += c.omega;
		ent += Math.log(Math.abs(c.disc) + 1);
		if (c.provenance === "lmfdb") famous += 1;
	}
	return {
		n,
		ranks,
		famous,
		meanOmega: om / n,
		meanEntropy: ent / n,
		maxConductor: curves[curves.length - 1]?.conductor ?? 0
	};
}
/** RTCH-E1 intrinsic feature vector — rank is held out as a response. */
function intrinsicFeatures(c) {
	return [
		Math.log1p(c.conductor),
		Math.sign(c.disc) * Math.log1p(Math.abs(c.disc)),
		Math.log1p(Math.abs(c.jinv)),
		c.faltingsHeight,
		Math.log1p(Math.max(0, c.regulator))
	];
}
var INTRINSIC_NAMES = [
	"log N",
	"sgn log |Δ|",
	"log |j|",
	"Faltings h",
	"log R"
];
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-Cu8J75Dn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-elevated text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:bg-elevated hover:text-fg",
			outline: "shadow-[var(--shadow-border)] text-fg hover:bg-elevated",
			link: "text-steel underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
function SheetContent({ className, children, side = "left", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: cn("fixed z-50 flex h-full w-[min(20rem,88vw)] flex-col bg-surface p-4 shadow-[var(--shadow-border)]", side === "left" ? "inset-y-0 left-0" : "inset-y-0 right-0", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 rounded-md p-2 text-muted hover:bg-elevated hover:text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
var TooltipProvider = Provider;
var H0_PLANCK = 67.4;
var H0_SHOES = 73.04;
var OMEGA_M = .315;
var OMEGA_L = .685;
function hashUnit(s, salt) {
	return hash32(s + ":" + salt) / 4294967296;
}
/** ACSC projection Φ(E): (r, log N, Reg) → (x,y,z). Conjectural mapping. */
function projectCurve(c, bounds) {
	const v = (Math.log(c.conductor) - bounds.lnMin) / Math.max(1e-6, bounds.lnMax - bounds.lnMin);
	const theta = hashUnit(c.label, "th") * Math.PI * 2;
	const phi = (.18 + hashUnit(c.label, "ph") * .82) * Math.PI;
	const w = Math.tanh(Math.log1p(c.regulator));
	const rad = (1 + .12 * Math.sin(3 * theta) + .08 * Math.cos(2 * phi)) * (.35 + .95 * v + .08 * c.rank);
	const obl = .86;
	return {
		...c,
		x: rad * Math.sin(phi) * Math.cos(theta),
		y: obl * rad * Math.sin(phi) * Math.sin(theta) + .16 * c.rank,
		z: rad * Math.cos(phi) + .1 * w,
		entropy: Math.log(Math.abs(c.disc) + 1),
		cohClass: Math.log(Math.abs(c.disc) + 1) * (c.rank + 1) / Math.sqrt(Math.max(1, c.conductor)),
		theta,
		phi
	};
}
function projectCatalog(curves = getCatalog()) {
	let lnMin = Infinity;
	let lnMax = -Infinity;
	for (const c of curves) {
		const l = Math.log(c.conductor);
		if (l < lnMin) lnMin = l;
		if (l > lnMax) lnMax = l;
	}
	return curves.map((c) => projectCurve(c, {
		lnMin,
		lnMax
	}));
}
function kNearest(points, k = 3) {
	const links = [];
	const seen = /* @__PURE__ */ new Set();
	for (let i = 0; i < points.length; i++) {
		const a = points[i];
		const dist = [];
		for (let j = 0; j < points.length; j++) {
			if (i === j) continue;
			const b = points[j];
			const d = (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2;
			dist.push({
				j,
				d
			});
		}
		dist.sort((p, q) => p.d - q.d);
		for (let n = 0; n < k && n < dist.length; n++) {
			const j = dist[n].j;
			const key = i < j ? `${i}-${j}` : `${j}-${i}`;
			if (seen.has(key)) continue;
			seen.add(key);
			links.push([i, j]);
		}
	}
	return links;
}
var PROJECTED = projectCatalog();
var FILAMENTS = kNearest(PROJECTED, 3);
function hLcdm(z, H0) {
	const zp = 1 + z;
	return H0 * Math.sqrt(OMEGA_M * zp * zp * zp + OMEGA_L);
}
/** Local-vs-global sampling weight w_E(z). Conjectural. */
function curveWeight(c, z) {
	const t = 1 / (1 + z);
	const local = Math.exp(.62 * c.rank) / (1 + .18 * Math.log(c.conductor));
	return (1 - t) * 1 + t * local;
}
function meanOmega(curves, z) {
	let num = 0;
	let den = 0;
	for (const c of curves) {
		const w = curveWeight(c, z);
		num += w * c.omega;
		den += w;
	}
	return den > 0 ? num / den : 1;
}
function entropyCurvature(z) {
	return Math.exp(-z / 1.85);
}
function metricTrace(z) {
	return 1 / Math.pow(1 + z, .72);
}
/**
* H_eff(z) = H_ΛCDM(z; H0 · ⟨Ω⟩_z/⟨Ω⟩_∞) + β κ(z) + γ Tr(δg)(z)
* Phenomenological S.T.A.R. expansion history. Calibrated so high-z recovers Planck.
*/
function hEff(z, curves, beta, gamma) {
	const omZ = meanOmega(curves, z);
	const omInf = meanOmega(curves, 1e5);
	return hLcdm(z, H0_PLANCK * Math.pow(omZ / Math.max(1e-9, omInf), .28)) + beta * entropyCurvature(z) * 5.15 + gamma * metricTrace(z) * 3.4;
}
/** Closed 2-form on T²: ω = dθ ∧ dφ, [ω] ≠ 0 in H²(T²). Established pullback. */
function pullbackDensity(dY1dx, dY1dy, dY2dx, dY2dy) {
	return dY1dx * dY2dy - dY1dy * dY2dx;
}
function localIq(Fxy) {
	return .25 * Fxy * Fxy;
}
var DEFAULT_RTCH = {
	lambdaQ: 1,
	alphaPhi: .22,
	alphaA: .12,
	betaQ: .35,
	lambdaScale: 1,
	topologyOn: true,
	conformalOn: true,
	freezeY: false,
	windingU: 1,
	windingV: 1,
	beta: .48,
	gamma: .22,
	pressure: 0
};
/** α_Q = β_Q / Λ_Q^4  — Appendix B minimal falsifiable model. */
function alphaQ(p) {
	if (!p.conformalOn) return 0;
	const L4 = Math.pow(Math.max(.25, p.lambdaScale), 4);
	return p.betaQ / L4;
}
function conformalA(phi, M, JQ, p) {
	if (!p.conformalOn) return 1;
	return Math.exp(p.alphaPhi * phi + p.alphaA * M + alphaQ(p) * JQ);
}
function matterTrace(rho, pressure) {
	return -rho + 3 * pressure;
}
/** Thermodynamic map Φ: (x,y) → T² with optional local deformation. Established pullback. */
function evaluateState(x, y, t, p) {
	const jitter = p.freezeY ? 0 : .18;
	const Y1 = p.windingU * 2 * Math.PI * x + jitter * Math.sin(2 * Math.PI * (3 * x + t * .35) + y);
	const Y2 = p.windingV * 2 * Math.PI * y + jitter * Math.cos(2 * Math.PI * (2 * y - t * .28) + x);
	const Y1x = p.windingU * 2 * Math.PI + jitter * 2 * Math.PI * 3 * Math.cos(2 * Math.PI * (3 * x + t * .35) + y);
	const Y1y = jitter * Math.cos(2 * Math.PI * (3 * x + t * .35) + y);
	const Y2x = jitter * -Math.sin(2 * Math.PI * (2 * y - t * .28) + x);
	const Y2y = p.windingV * 2 * Math.PI + jitter * 2 * Math.PI * 2 * -Math.sin(2 * Math.PI * (2 * y - t * .28) + x);
	const Fxy = p.freezeY ? 0 : pullbackDensity(Y1x, Y1y, Y2x, Y2y);
	const JQ = localIq(Fxy);
	const phi = .25 * Math.sin(Y1) * Math.cos(Y2);
	const M = .4 + .2 * Math.sin(Y1 + Y2);
	const A = conformalA(phi, M, JQ, p);
	return {
		Y1,
		Y2,
		Fxy,
		JQ,
		phi,
		M,
		A,
		lnA: Math.log(Math.max(1e-9, A))
	};
}
function gradLnA(x, y, t, p) {
	const h = .008;
	const c = evaluateState(x, y, t, p).lnA;
	return {
		dx: (evaluateState(Math.min(.992, x + h), y, t, p).lnA - c) / h,
		dy: (evaluateState(x, Math.min(.992, y + h), t, p).lnA - c) / h,
		lnA: c
	};
}
var LIMITS = {
	minimal: DEFAULT_RTCH,
	gr: {
		topologyOn: false,
		conformalOn: false,
		lambdaQ: 0,
		alphaPhi: 0,
		alphaA: 0,
		betaQ: 0,
		freezeY: false
	},
	"local-only": {
		topologyOn: false,
		lambdaQ: 0,
		conformalOn: true,
		betaQ: .35
	},
	"topo-only": {
		topologyOn: true,
		lambdaQ: 1,
		conformalOn: true,
		betaQ: 0
	},
	"no-conformal": {
		conformalOn: false,
		alphaPhi: 0,
		alphaA: 0,
		betaQ: 0
	},
	"frozen-y": { freezeY: true }
};
var LIMIT_META = {
	minimal: {
		label: "Full RTCH",
		note: "λ_Q ≠ 0 and β_Q ≠ 0",
		pair: "(≠0, ≠0)"
	},
	gr: {
		label: "GR limit",
		note: "no cohomological interaction",
		pair: "(0, 0)"
	},
	"local-only": {
		label: "Local only",
		note: "A(J_Q) without B ∧ F_Q",
		pair: "(0, ≠0)"
	},
	"topo-only": {
		label: "Topological only",
		note: "B ∧ F_Q, β_Q = 0",
		pair: "(≠0, 0)"
	},
	"no-conformal": {
		label: "A = 1",
		note: "geodesics recovered",
		pair: "A ≡ 1"
	},
	"frozen-y": {
		label: "Frozen Y",
		note: "F_Q vanishes locally",
		pair: "dY = 0"
	}
};
var useLab = create()((set) => ({
	...DEFAULT_RTCH,
	z: 0,
	selectedLabel: "37.a1",
	set: (p) => set(p),
	applyLimit: (id) => set({
		...DEFAULT_RTCH,
		...LIMITS[id]
	}),
	reset: () => set({
		...DEFAULT_RTCH,
		z: 0,
		selectedLabel: "37.a1"
	})
}));
var PRIMARY = [
	{
		to: "/",
		label: "Deck",
		icon: Compass
	},
	{
		to: "/dynamics",
		label: "Dynamics",
		icon: Waves
	},
	{
		to: "/hubble",
		label: "Hubble",
		icon: Activity
	},
	{
		to: "/cohomology",
		label: "Charge",
		icon: Hexagon
	},
	{
		to: "/action",
		label: "Action",
		icon: Atom
	},
	{
		to: "/experiment",
		label: "E1",
		icon: FlaskConical
	}
];
var SECONDARY = [
	{
		to: "/projection",
		label: "Projection",
		icon: Orbit
	},
	{
		to: "/catalog",
		label: "Catalog",
		icon: Table2
	},
	{
		to: "/theory",
		label: "Theory",
		icon: BookOpen
	}
];
function NavLinks({ onClick }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex flex-col gap-1",
		children: [...PRIMARY, ...SECONDARY].map((item) => {
			const active = pathname === item.to;
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				onClick,
				className: cn("flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors", active ? "bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted hover:bg-elevated/70 hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
			}, item.to);
		})
	});
}
function Wordmark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "flex items-baseline gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl tracking-tight text-fg",
			children: "STARMAP"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden font-mono text-[10px] uppercase tracking-[0.18em] text-subtle sm:inline",
			children: "RTCH Lab"
		})]
	});
}
function Shell({ children }) {
	const z = useLab((s) => s.z);
	const beta = useLab((s) => s.beta);
	const gamma = useLab((s) => s.gamma);
	const H = hEff(z, getCatalog(), beta, gamma) / hLcdm(z, 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-dvh bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-border bg-bg/90 px-4 backdrop-blur-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "lg:hidden",
								"aria-label": "Open navigation",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
							side: "left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-6 mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden text-right sm:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
									children: "H0_eff"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-mono text-sm tabular-nums text-fg",
									children: [
										H.toFixed(2),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: "km/s/Mpc"
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden text-right md:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
									children: "Catalog"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-mono text-sm tabular-nums text-fg",
									children: [PROJECTED.length, " curves"]
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-[1400px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "sticky top-14 hidden h-[calc(100dvh-3.5rem)] w-52 shrink-0 overflow-y-auto border-r border-border p-4 lg:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 font-mono text-[10px] leading-relaxed text-subtle",
							children: "Symbolic–Topological–Arithmetic Relativity"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "min-w-0 flex-1 px-4 py-6 pb-24 lg:px-8 lg:pb-10",
						children
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed inset-x-0 bottom-0 z-40 grid grid-cols-6 border-t border-border bg-bg/95 lg:hidden",
					children: PRIMARY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTab, { ...item }, item.to))
				})
			]
		})
	});
}
function MobileTab({ to, label, icon: Icon }) {
	const active = useRouterState({ select: (s) => s.location.pathname }) === to;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[10px] tracking-wide", active ? "text-fg" : "text-muted"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
var styles_default = "/assets/styles-_fX3g-Ol.css";
var APP_NAME = "STARMAP";
var Route$9 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#08090b"
			},
			{
				name: "description",
				content: "STARMAP laboratory for Relativistic Thermodynamic Cohomology — unified particle and fluid dynamics, nested null hypotheses, and the RTCH-E1 topology test."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&family=Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$8 = () => import("./routes-U4NqOG9I.mjs");
var Route$8 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./action-OZdm1fv4.mjs");
var Route$7 = createFileRoute("/action")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./catalog-BA14jdQf.mjs");
var Route$6 = createFileRoute("/catalog")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./cohomology-KJKOjQpo.mjs");
var Route$5 = createFileRoute("/cohomology")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./dynamics-BV5pK42Y.mjs");
var Route$4 = createFileRoute("/dynamics")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./experiment-BMsA8Gj4.mjs");
var Route$3 = createFileRoute("/experiment")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./hubble-BvwJYZQQ.mjs");
var Route$2 = createFileRoute("/hubble")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./projection-BSsFRoKw.mjs");
var Route$1 = createFileRoute("/projection")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./theory-BSAgeuke.mjs");
var Route = createFileRoute("/theory")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$8.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$9
	}),
	ActionRoute: Route$7.update({
		id: "/action",
		path: "/action",
		getParentRoute: () => Route$9
	}),
	CatalogRoute: Route$6.update({
		id: "/catalog",
		path: "/catalog",
		getParentRoute: () => Route$9
	}),
	CohomologyRoute: Route$5.update({
		id: "/cohomology",
		path: "/cohomology",
		getParentRoute: () => Route$9
	}),
	DynamicsRoute: Route$4.update({
		id: "/dynamics",
		path: "/dynamics",
		getParentRoute: () => Route$9
	}),
	ExperimentRoute: Route$3.update({
		id: "/experiment",
		path: "/experiment",
		getParentRoute: () => Route$9
	}),
	HubbleRoute: Route$2.update({
		id: "/hubble",
		path: "/hubble",
		getParentRoute: () => Route$9
	}),
	ProjectionRoute: Route$1.update({
		id: "/projection",
		path: "/projection",
		getParentRoute: () => Route$9
	}),
	TheoryRoute: Route.update({
		id: "/theory",
		path: "/theory",
		getParentRoute: () => Route$9
	})
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getCatalog as C, catalogStats as S, mulberry32 as T, pullbackDensity as _, H0_PLANCK as a, INTRINSIC_NAMES as b, alphaQ as c, gradLnA as d, hEff as f, meanOmega as g, matterTrace as h, FILAMENTS as i, conformalA as l, localIq as m, LIMIT_META as n, H0_SHOES as o, hLcdm as p, useLab as r, PROJECTED as s, router_exports as t, evaluateState as u, Button as v, intrinsicFeatures as w, KAPPA_UCF as x, CLUSTERS as y };
