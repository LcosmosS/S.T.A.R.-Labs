import { useEffect, useRef } from "react";
import type { Interval } from "@/lib/star/rtch-e1";

export function BarcodeCanvas({ intervals, className }: { intervals: Interval[]; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const draw = () => {
      const r = wrap.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(r.width * dpr));
      canvas.height = Math.max(1, Math.floor(r.height * dpr));
      canvas.style.width = `${r.width}px`;
      canvas.style.height = `${r.height}px`;
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = "#111318";
      ctx.fillRect(0, 0, w, h);
      const bars = intervals.slice(0, 18);
      const maxD = Math.max(0.001, ...bars.map((b) => b.death));
      const pad = 16 * dpr;
      const row = (h - pad * 2) / Math.max(1, bars.length);
      bars.forEach((b, i) => {
        const y = pad + i * row + row * 0.25;
        const x0 = pad;
        const x1 = pad + (b.death / maxD) * (w - pad * 2);
        ctx.fillStyle = "rgba(138,160,181,0.85)";
        ctx.fillRect(x0, y, Math.max(2 * dpr, x1 - x0), row * 0.45);
      });
      ctx.fillStyle = "#8b919c";
      ctx.font = `${10 * dpr}px "IBM Plex Mono"`;
      ctx.fillText("H0 barcode  ·  birth = 0", pad, h - 6 * dpr);
    };

    draw();
    const ro = new ResizeObserver(draw);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [intervals]);

  return (
    <div ref={wrapRef} className={className}>
      <canvas ref={canvasRef} className="block size-full" />
    </div>
  );
}

export function PcaCanvas({
  points,
  className,
}: {
  points: Array<{ x: number; y: number; rank: number }>;
  className?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const draw = () => {
      const r = wrap.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(r.width * dpr));
      canvas.height = Math.max(1, Math.floor(r.height * dpr));
      canvas.style.width = `${r.width}px`;
      canvas.style.height = `${r.height}px`;
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = "#111318";
      ctx.fillRect(0, 0, w, h);
      let xmin = Infinity;
      let xmax = -Infinity;
      let ymin = Infinity;
      let ymax = -Infinity;
      for (const p of points) {
        xmin = Math.min(xmin, p.x);
        xmax = Math.max(xmax, p.x);
        ymin = Math.min(ymin, p.y);
        ymax = Math.max(ymax, p.y);
      }
      const dx = xmax - xmin || 1;
      const dy = ymax - ymin || 1;
      const pad = 18 * dpr;
      for (const p of points) {
        const x = pad + ((p.x - xmin) / dx) * (w - pad * 2);
        const y = pad + ((p.y - ymin) / dy) * (h - pad * 2);
        const lum = 140 + p.rank * 22;
        ctx.beginPath();
        ctx.arc(x, y, (2 + p.rank * 0.6) * dpr, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${lum - 30},${lum},${lum + 20},0.9)`;
        ctx.fill();
      }
      ctx.fillStyle = "#8b919c";
      ctx.font = `${10 * dpr}px "IBM Plex Mono"`;
      ctx.fillText("PCA of intrinsic features  ·  rank held out", pad, h - 6 * dpr);
    };
    draw();
    const ro = new ResizeObserver(draw);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [points]);

  return (
    <div ref={wrapRef} className={className}>
      <canvas ref={canvasRef} className="block size-full" />
    </div>
  );
}
