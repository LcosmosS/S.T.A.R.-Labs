import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Metric } from "@/components/viz/formula";
import { BarcodeCanvas, PcaCanvas } from "@/components/viz/barcode-canvas";
import { runExperiment, type ExperimentResult } from "@/lib/star/rtch-e1";

export const Route = createFileRoute("/experiment")({ component: ExperimentPage });

type Kind = "catalog" | "torus" | "scrambled";

function ExperimentPage() {
  const [kind, setKind] = useState<Kind>("catalog");
  const [version, setVersion] = useState(0);
  const [busy, setBusy] = useState(false);

  const result = useMemo(() => {
    void version;
    return runExperiment({ kind, nNulls: 18, k: 8, nPairs: 28, seed: 20260917 + version });
  }, [kind, version]);

  function rerun(next: Kind) {
    setBusy(true);
    setKind(next);
    setVersion((v) => v + 1);
    requestAnimationFrame(() => setBusy(false));
  }

  return (
    <div className="space-y-8">
      <header className="max-w-2xl">
        <Badge tone="steel">RTCH-E1</Badge>
        <h1 className="mt-3 font-display text-4xl tracking-tight">Arithmetic–geodesic–cohomological test</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          A persistent feature of a finite point cloud is evidence at a scale — not a proof that the arithmetic state
          space is a manifold with H^k ≠ 0. Rank is held out of the metric. Structure is compared to N1: independent
          column permutation, preserving every marginal.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant={kind === "catalog" ? "default" : "secondary"} onClick={() => rerun("catalog")}>
          Catalog
        </Button>
        <Button size="sm" variant={kind === "torus" ? "default" : "secondary"} onClick={() => rerun("torus")}>
          Torus control
        </Button>
        <Button size="sm" variant={kind === "scrambled" ? "default" : "secondary"} onClick={() => rerun("scrambled")}>
          N1 scramble
        </Button>
      </div>

      <Verdict result={result} busy={busy} />

      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="n" value={String(result.n)} hint={`${result.features.length} features`} />
        <Metric label="H0 max pers." value={result.h0Max.toFixed(3)} hint={`p = ${result.nullH0.p.toFixed(3)} vs N1`} />
        <Metric label="kNN β₁" value={String(result.betti1)} hint={`p = ${result.nullBetti.p.toFixed(3)}`} />
        <Metric label="⟨tortuosity⟩" value={result.geodesic.meanTort.toFixed(3)} hint={`p = ${result.nullTort.p.toFixed(3)}`} />
      </div>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
          <div className="px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">H0 persistence</div>
          <BarcodeCanvas intervals={result.intervals} className="h-56 w-full" />
        </div>
        <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
          <div className="px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">Scalar embedding</div>
          <PcaCanvas points={result.pca} className="h-56 w-full" />
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <article className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <h2 className="font-display text-xl tracking-tight">Null protocol</h2>
          <ul className="mt-3 space-y-2 text-sm leading-relaxed text-muted">
            <li>N1 — independently permute each intrinsic column.</li>
            <li>Primary features: log N, sgn log |Δ|, log |j|, Faltings height, log R.</li>
            <li>Graph geodesics exclude direct kNN neighbors, so reported tortuosity is a multi-edge path.</li>
            <li>Positive control uses a sampled torus in R³, not Fibonacci or golden-ratio maps.</li>
          </ul>
        </article>
        <article className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <h2 className="font-display text-xl tracking-tight">Geodesic sample</h2>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left font-mono text-[11px]">
              <thead className="text-subtle">
                <tr>
                  <th className="py-1 pr-3">i</th>
                  <th className="py-1 pr-3">j</th>
                  <th className="py-1 pr-3">graph</th>
                  <th className="py-1 pr-3">chord</th>
                  <th className="py-1">τ</th>
                </tr>
              </thead>
              <tbody>
                {result.geodesic.pairs.slice(0, 6).map((p) => (
                  <tr key={`${p.i}-${p.j}`} className="text-fg">
                    <td className="py-1 pr-3 tabular-nums">{p.i}</td>
                    <td className="py-1 pr-3 tabular-nums">{p.j}</td>
                    <td className="py-1 pr-3 tabular-nums">{p.graph.toFixed(3)}</td>
                    <td className="py-1 pr-3 tabular-nums">{p.chord.toFixed(3)}</td>
                    <td className="py-1 tabular-nums">{p.tortuosity.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </article>
      </section>

      <section>
        <h2 className="font-display text-xl tracking-tight">Caveats</h2>
        <ul className="mt-3 max-w-2xl space-y-2 text-sm leading-relaxed text-muted">
          {result.caveats.map((c) => (
            <li key={c}>{c}</li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function Verdict({ result, busy }: { result: ExperimentResult; busy: boolean }) {
  const tone = result.kind === "torus" ? "ok" : result.nullH0.p < 0.05 || result.nullBetti.p < 0.05 ? "warn" : "default";
  return (
    <div className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={tone}>{result.kind}</Badge>
        <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-subtle">
          {result.nNulls} nulls · k = {result.k}
          {busy ? " · running" : ""}
        </span>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-fg">{result.verdict}</p>
    </div>
  );
}
